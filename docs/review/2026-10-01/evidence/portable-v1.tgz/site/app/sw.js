(function() {
	//#region ../../node_modules/.pnpm/workbox-core@7.4.1/node_modules/workbox-core/_version.js
	try {
		self["workbox:core:7.4.0"] && _();
	} catch (e) {}
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-core@7.4.1/node_modules/workbox-core/models/messages/messageGenerator.js
	var fallback = (code, ...args) => {
		let msg = code;
		if (args.length > 0) msg += ` :: ${JSON.stringify(args)}`;
		return msg;
	};
	var messageGenerator = fallback;
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-core@7.4.1/node_modules/workbox-core/_private/WorkboxError.js
	/**
	* Workbox errors should be thrown with this class.
	* This allows use to ensure the type easily in tests,
	* helps developers identify errors from workbox
	* easily and allows use to optimise error
	* messages correctly.
	*
	* @private
	*/
	var WorkboxError = class extends Error {
		/**
		*
		* @param {string} errorCode The error code that
		* identifies this particular error.
		* @param {Object=} details Any relevant arguments
		* that will help developers identify issues should
		* be added as a key on the context object.
		*/
		constructor(errorCode, details) {
			const message = messageGenerator(errorCode, details);
			super(message);
			this.name = errorCode;
			this.details = details;
		}
	};
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-core@7.4.1/node_modules/workbox-core/_private/cacheNames.js
	var _cacheNameDetails = {
		googleAnalytics: "googleAnalytics",
		precache: "precache-v2",
		prefix: "workbox",
		runtime: "runtime",
		suffix: typeof registration !== "undefined" ? registration.scope : ""
	};
	var _createCacheName = (cacheName) => {
		return [
			_cacheNameDetails.prefix,
			cacheName,
			_cacheNameDetails.suffix
		].filter((value) => value && value.length > 0).join("-");
	};
	var eachCacheNameDetail = (fn) => {
		for (const key of Object.keys(_cacheNameDetails)) fn(key);
	};
	var cacheNames = {
		updateDetails: (details) => {
			eachCacheNameDetail((key) => {
				if (typeof details[key] === "string") _cacheNameDetails[key] = details[key];
			});
		},
		getGoogleAnalyticsName: (userCacheName) => {
			return userCacheName || _createCacheName(_cacheNameDetails.googleAnalytics);
		},
		getPrecacheName: (userCacheName) => {
			return userCacheName || _createCacheName(_cacheNameDetails.precache);
		},
		getPrefix: () => {
			return _cacheNameDetails.prefix;
		},
		getRuntimeName: (userCacheName) => {
			return userCacheName || _createCacheName(_cacheNameDetails.runtime);
		},
		getSuffix: () => {
			return _cacheNameDetails.suffix;
		}
	};
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-core@7.4.1/node_modules/workbox-core/_private/waitUntil.js
	/**
	* A utility method that makes it easier to use `event.waitUntil` with
	* async functions and return the result.
	*
	* @param {ExtendableEvent} event
	* @param {Function} asyncFn
	* @return {Function}
	* @private
	*/
	function waitUntil(event, asyncFn) {
		const returnPromise = asyncFn();
		event.waitUntil(returnPromise);
		return returnPromise;
	}
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-precaching@7.4.1/node_modules/workbox-precaching/_version.js
	try {
		self["workbox:precaching:7.4.0"] && _();
	} catch (e) {}
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-precaching@7.4.1/node_modules/workbox-precaching/utils/createCacheKey.js
	var REVISION_SEARCH_PARAM = "__WB_REVISION__";
	/**
	* Converts a manifest entry into a versioned URL suitable for precaching.
	*
	* @param {Object|string} entry
	* @return {string} A URL with versioning info.
	*
	* @private
	* @memberof workbox-precaching
	*/
	function createCacheKey(entry) {
		if (!entry) throw new WorkboxError("add-to-cache-list-unexpected-type", { entry });
		if (typeof entry === "string") {
			const urlObject = new URL(entry, location.href);
			return {
				cacheKey: urlObject.href,
				url: urlObject.href
			};
		}
		const { revision, url } = entry;
		if (!url) throw new WorkboxError("add-to-cache-list-unexpected-type", { entry });
		if (!revision) {
			const urlObject = new URL(url, location.href);
			return {
				cacheKey: urlObject.href,
				url: urlObject.href
			};
		}
		const cacheKeyURL = new URL(url, location.href);
		const originalURL = new URL(url, location.href);
		cacheKeyURL.searchParams.set(REVISION_SEARCH_PARAM, revision);
		return {
			cacheKey: cacheKeyURL.href,
			url: originalURL.href
		};
	}
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-precaching@7.4.1/node_modules/workbox-precaching/utils/PrecacheInstallReportPlugin.js
	/**
	* A plugin, designed to be used with PrecacheController, to determine the
	* of assets that were updated (or not updated) during the install event.
	*
	* @private
	*/
	var PrecacheInstallReportPlugin = class {
		constructor() {
			this.updatedURLs = [];
			this.notUpdatedURLs = [];
			this.handlerWillStart = async ({ request, state }) => {
				if (state) state.originalRequest = request;
			};
			this.cachedResponseWillBeUsed = async ({ event, state, cachedResponse }) => {
				if (event.type === "install") {
					if (state && state.originalRequest && state.originalRequest instanceof Request) {
						const url = state.originalRequest.url;
						if (cachedResponse) this.notUpdatedURLs.push(url);
						else this.updatedURLs.push(url);
					}
				}
				return cachedResponse;
			};
		}
	};
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-precaching@7.4.1/node_modules/workbox-precaching/utils/PrecacheCacheKeyPlugin.js
	/**
	* A plugin, designed to be used with PrecacheController, to translate URLs into
	* the corresponding cache key, based on the current revision info.
	*
	* @private
	*/
	var PrecacheCacheKeyPlugin = class {
		constructor({ precacheController }) {
			this.cacheKeyWillBeUsed = async ({ request, params }) => {
				const cacheKey = (params === null || params === void 0 ? void 0 : params.cacheKey) || this._precacheController.getCacheKeyForURL(request.url);
				return cacheKey ? new Request(cacheKey, { headers: request.headers }) : request;
			};
			this._precacheController = precacheController;
		}
	};
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-core@7.4.1/node_modules/workbox-core/_private/canConstructResponseFromBodyStream.js
	var supportStatus;
	/**
	* A utility function that determines whether the current browser supports
	* constructing a new `Response` from a `response.body` stream.
	*
	* @return {boolean} `true`, if the current browser can successfully
	*     construct a `Response` from a `response.body` stream, `false` otherwise.
	*
	* @private
	*/
	function canConstructResponseFromBodyStream() {
		if (supportStatus === void 0) {
			const testResponse = new Response("");
			if ("body" in testResponse) try {
				new Response(testResponse.body);
				supportStatus = true;
			} catch (error) {
				supportStatus = false;
			}
			supportStatus = false;
		}
		return supportStatus;
	}
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-core@7.4.1/node_modules/workbox-core/copyResponse.js
	/**
	* Allows developers to copy a response and modify its `headers`, `status`,
	* or `statusText` values (the values settable via a
	* [`ResponseInit`]{@link https://developer.mozilla.org/en-US/docs/Web/API/Response/Response#Syntax}
	* object in the constructor).
	* To modify these values, pass a function as the second argument. That
	* function will be invoked with a single object with the response properties
	* `{headers, status, statusText}`. The return value of this function will
	* be used as the `ResponseInit` for the new `Response`. To change the values
	* either modify the passed parameter(s) and return it, or return a totally
	* new object.
	*
	* This method is intentionally limited to same-origin responses, regardless of
	* whether CORS was used or not.
	*
	* @param {Response} response
	* @param {Function} modifier
	* @memberof workbox-core
	*/
	async function copyResponse(response, modifier) {
		let origin = null;
		if (response.url) origin = new URL(response.url).origin;
		if (origin !== self.location.origin) throw new WorkboxError("cross-origin-copy-response", { origin });
		const clonedResponse = response.clone();
		const responseInit = {
			headers: new Headers(clonedResponse.headers),
			status: clonedResponse.status,
			statusText: clonedResponse.statusText
		};
		const modifiedResponseInit = modifier ? modifier(responseInit) : responseInit;
		const body = canConstructResponseFromBodyStream() ? clonedResponse.body : await clonedResponse.blob();
		return new Response(body, modifiedResponseInit);
	}
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-core@7.4.1/node_modules/workbox-core/_private/getFriendlyURL.js
	var getFriendlyURL = (url) => {
		return new URL(String(url), location.href).href.replace(new RegExp(`^${location.origin}`), "");
	};
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-core@7.4.1/node_modules/workbox-core/_private/cacheMatchIgnoreParams.js
	function stripParams(fullURL, ignoreParams) {
		const strippedURL = new URL(fullURL);
		for (const param of ignoreParams) strippedURL.searchParams.delete(param);
		return strippedURL.href;
	}
	/**
	* Matches an item in the cache, ignoring specific URL params. This is similar
	* to the `ignoreSearch` option, but it allows you to ignore just specific
	* params (while continuing to match on the others).
	*
	* @private
	* @param {Cache} cache
	* @param {Request} request
	* @param {Object} matchOptions
	* @param {Array<string>} ignoreParams
	* @return {Promise<Response|undefined>}
	*/
	async function cacheMatchIgnoreParams(cache, request, ignoreParams, matchOptions) {
		const strippedRequestURL = stripParams(request.url, ignoreParams);
		if (request.url === strippedRequestURL) return cache.match(request, matchOptions);
		const keysOptions = Object.assign(Object.assign({}, matchOptions), { ignoreSearch: true });
		const cacheKeys = await cache.keys(request, keysOptions);
		for (const cacheKey of cacheKeys) if (strippedRequestURL === stripParams(cacheKey.url, ignoreParams)) return cache.match(cacheKey, matchOptions);
	}
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-core@7.4.1/node_modules/workbox-core/_private/Deferred.js
	/**
	* The Deferred class composes Promises in a way that allows for them to be
	* resolved or rejected from outside the constructor. In most cases promises
	* should be used directly, but Deferreds can be necessary when the logic to
	* resolve a promise must be separate.
	*
	* @private
	*/
	var Deferred = class {
		/**
		* Creates a promise and exposes its resolve and reject functions as methods.
		*/
		constructor() {
			this.promise = new Promise((resolve, reject) => {
				this.resolve = resolve;
				this.reject = reject;
			});
		}
	};
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-core@7.4.1/node_modules/workbox-core/models/quotaErrorCallbacks.js
	var quotaErrorCallbacks = /* @__PURE__ */ new Set();
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-core@7.4.1/node_modules/workbox-core/_private/executeQuotaErrorCallbacks.js
	/**
	* Runs all of the callback functions, one at a time sequentially, in the order
	* in which they were registered.
	*
	* @memberof workbox-core
	* @private
	*/
	async function executeQuotaErrorCallbacks() {
		for (const callback of quotaErrorCallbacks) await callback();
	}
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-core@7.4.1/node_modules/workbox-core/_private/timeout.js
	/**
	* Returns a promise that resolves and the passed number of milliseconds.
	* This utility is an async/await-friendly version of `setTimeout`.
	*
	* @param {number} ms
	* @return {Promise}
	* @private
	*/
	function timeout(ms) {
		return new Promise((resolve) => setTimeout(resolve, ms));
	}
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-strategies@7.4.1/node_modules/workbox-strategies/_version.js
	try {
		self["workbox:strategies:7.4.0"] && _();
	} catch (e) {}
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-strategies@7.4.1/node_modules/workbox-strategies/StrategyHandler.js
	function toRequest(input) {
		return typeof input === "string" ? new Request(input) : input;
	}
	/**
	* A class created every time a Strategy instance calls
	* {@link workbox-strategies.Strategy~handle} or
	* {@link workbox-strategies.Strategy~handleAll} that wraps all fetch and
	* cache actions around plugin callbacks and keeps track of when the strategy
	* is "done" (i.e. all added `event.waitUntil()` promises have resolved).
	*
	* @memberof workbox-strategies
	*/
	var StrategyHandler = class {
		/**
		* Creates a new instance associated with the passed strategy and event
		* that's handling the request.
		*
		* The constructor also initializes the state that will be passed to each of
		* the plugins handling this request.
		*
		* @param {workbox-strategies.Strategy} strategy
		* @param {Object} options
		* @param {Request|string} options.request A request to run this strategy for.
		* @param {ExtendableEvent} options.event The event associated with the
		*     request.
		* @param {URL} [options.url]
		* @param {*} [options.params] The return value from the
		*     {@link workbox-routing~matchCallback} (if applicable).
		*/
		constructor(strategy, options) {
			this._cacheKeys = {};
			Object.assign(this, options);
			this.event = options.event;
			this._strategy = strategy;
			this._handlerDeferred = new Deferred();
			this._extendLifetimePromises = [];
			this._plugins = [...strategy.plugins];
			this._pluginStateMap = /* @__PURE__ */ new Map();
			for (const plugin of this._plugins) this._pluginStateMap.set(plugin, {});
			this.event.waitUntil(this._handlerDeferred.promise);
		}
		/**
		* Fetches a given request (and invokes any applicable plugin callback
		* methods) using the `fetchOptions` (for non-navigation requests) and
		* `plugins` defined on the `Strategy` object.
		*
		* The following plugin lifecycle methods are invoked when using this method:
		* - `requestWillFetch()`
		* - `fetchDidSucceed()`
		* - `fetchDidFail()`
		*
		* @param {Request|string} input The URL or request to fetch.
		* @return {Promise<Response>}
		*/
		async fetch(input) {
			const { event } = this;
			let request = toRequest(input);
			if (request.mode === "navigate" && event instanceof FetchEvent && event.preloadResponse) {
				const possiblePreloadResponse = await event.preloadResponse;
				if (possiblePreloadResponse) return possiblePreloadResponse;
			}
			const originalRequest = this.hasCallback("fetchDidFail") ? request.clone() : null;
			try {
				for (const cb of this.iterateCallbacks("requestWillFetch")) request = await cb({
					request: request.clone(),
					event
				});
			} catch (err) {
				if (err instanceof Error) throw new WorkboxError("plugin-error-request-will-fetch", { thrownErrorMessage: err.message });
			}
			const pluginFilteredRequest = request.clone();
			try {
				let fetchResponse;
				fetchResponse = await fetch(request, request.mode === "navigate" ? void 0 : this._strategy.fetchOptions);
				for (const callback of this.iterateCallbacks("fetchDidSucceed")) fetchResponse = await callback({
					event,
					request: pluginFilteredRequest,
					response: fetchResponse
				});
				return fetchResponse;
			} catch (error) {
				if (originalRequest) await this.runCallbacks("fetchDidFail", {
					error,
					event,
					originalRequest: originalRequest.clone(),
					request: pluginFilteredRequest.clone()
				});
				throw error;
			}
		}
		/**
		* Calls `this.fetch()` and (in the background) runs `this.cachePut()` on
		* the response generated by `this.fetch()`.
		*
		* The call to `this.cachePut()` automatically invokes `this.waitUntil()`,
		* so you do not have to manually call `waitUntil()` on the event.
		*
		* @param {Request|string} input The request or URL to fetch and cache.
		* @return {Promise<Response>}
		*/
		async fetchAndCachePut(input) {
			const response = await this.fetch(input);
			const responseClone = response.clone();
			this.waitUntil(this.cachePut(input, responseClone));
			return response;
		}
		/**
		* Matches a request from the cache (and invokes any applicable plugin
		* callback methods) using the `cacheName`, `matchOptions`, and `plugins`
		* defined on the strategy object.
		*
		* The following plugin lifecycle methods are invoked when using this method:
		* - cacheKeyWillBeUsed()
		* - cachedResponseWillBeUsed()
		*
		* @param {Request|string} key The Request or URL to use as the cache key.
		* @return {Promise<Response|undefined>} A matching response, if found.
		*/
		async cacheMatch(key) {
			const request = toRequest(key);
			let cachedResponse;
			const { cacheName, matchOptions } = this._strategy;
			const effectiveRequest = await this.getCacheKey(request, "read");
			const multiMatchOptions = Object.assign(Object.assign({}, matchOptions), { cacheName });
			cachedResponse = await caches.match(effectiveRequest, multiMatchOptions);
			for (const callback of this.iterateCallbacks("cachedResponseWillBeUsed")) cachedResponse = await callback({
				cacheName,
				matchOptions,
				cachedResponse,
				request: effectiveRequest,
				event: this.event
			}) || void 0;
			return cachedResponse;
		}
		/**
		* Puts a request/response pair in the cache (and invokes any applicable
		* plugin callback methods) using the `cacheName` and `plugins` defined on
		* the strategy object.
		*
		* The following plugin lifecycle methods are invoked when using this method:
		* - cacheKeyWillBeUsed()
		* - cacheWillUpdate()
		* - cacheDidUpdate()
		*
		* @param {Request|string} key The request or URL to use as the cache key.
		* @param {Response} response The response to cache.
		* @return {Promise<boolean>} `false` if a cacheWillUpdate caused the response
		* not be cached, and `true` otherwise.
		*/
		async cachePut(key, response) {
			const request = toRequest(key);
			await timeout(0);
			const effectiveRequest = await this.getCacheKey(request, "write");
			if (!response) throw new WorkboxError("cache-put-with-no-response", { url: getFriendlyURL(effectiveRequest.url) });
			const responseToCache = await this._ensureResponseSafeToCache(response);
			if (!responseToCache) return false;
			const { cacheName, matchOptions } = this._strategy;
			const cache = await self.caches.open(cacheName);
			const hasCacheUpdateCallback = this.hasCallback("cacheDidUpdate");
			const oldResponse = hasCacheUpdateCallback ? await cacheMatchIgnoreParams(cache, effectiveRequest.clone(), ["__WB_REVISION__"], matchOptions) : null;
			try {
				await cache.put(effectiveRequest, hasCacheUpdateCallback ? responseToCache.clone() : responseToCache);
			} catch (error) {
				if (error instanceof Error) {
					if (error.name === "QuotaExceededError") await executeQuotaErrorCallbacks();
					throw error;
				}
			}
			for (const callback of this.iterateCallbacks("cacheDidUpdate")) await callback({
				cacheName,
				oldResponse,
				newResponse: responseToCache.clone(),
				request: effectiveRequest,
				event: this.event
			});
			return true;
		}
		/**
		* Checks the list of plugins for the `cacheKeyWillBeUsed` callback, and
		* executes any of those callbacks found in sequence. The final `Request`
		* object returned by the last plugin is treated as the cache key for cache
		* reads and/or writes. If no `cacheKeyWillBeUsed` plugin callbacks have
		* been registered, the passed request is returned unmodified
		*
		* @param {Request} request
		* @param {string} mode
		* @return {Promise<Request>}
		*/
		async getCacheKey(request, mode) {
			const key = `${request.url} | ${mode}`;
			if (!this._cacheKeys[key]) {
				let effectiveRequest = request;
				for (const callback of this.iterateCallbacks("cacheKeyWillBeUsed")) effectiveRequest = toRequest(await callback({
					mode,
					request: effectiveRequest,
					event: this.event,
					params: this.params
				}));
				this._cacheKeys[key] = effectiveRequest;
			}
			return this._cacheKeys[key];
		}
		/**
		* Returns true if the strategy has at least one plugin with the given
		* callback.
		*
		* @param {string} name The name of the callback to check for.
		* @return {boolean}
		*/
		hasCallback(name) {
			for (const plugin of this._strategy.plugins) if (name in plugin) return true;
			return false;
		}
		/**
		* Runs all plugin callbacks matching the given name, in order, passing the
		* given param object (merged ith the current plugin state) as the only
		* argument.
		*
		* Note: since this method runs all plugins, it's not suitable for cases
		* where the return value of a callback needs to be applied prior to calling
		* the next callback. See
		* {@link workbox-strategies.StrategyHandler#iterateCallbacks}
		* below for how to handle that case.
		*
		* @param {string} name The name of the callback to run within each plugin.
		* @param {Object} param The object to pass as the first (and only) param
		*     when executing each callback. This object will be merged with the
		*     current plugin state prior to callback execution.
		*/
		async runCallbacks(name, param) {
			for (const callback of this.iterateCallbacks(name)) await callback(param);
		}
		/**
		* Accepts a callback and returns an iterable of matching plugin callbacks,
		* where each callback is wrapped with the current handler state (i.e. when
		* you call each callback, whatever object parameter you pass it will
		* be merged with the plugin's current state).
		*
		* @param {string} name The name fo the callback to run
		* @return {Array<Function>}
		*/
		*iterateCallbacks(name) {
			for (const plugin of this._strategy.plugins) if (typeof plugin[name] === "function") {
				const state = this._pluginStateMap.get(plugin);
				const statefulCallback = (param) => {
					const statefulParam = Object.assign(Object.assign({}, param), { state });
					return plugin[name](statefulParam);
				};
				yield statefulCallback;
			}
		}
		/**
		* Adds a promise to the
		* [extend lifetime promises]{@link https://w3c.github.io/ServiceWorker/#extendableevent-extend-lifetime-promises}
		* of the event associated with the request being handled (usually a
		* `FetchEvent`).
		*
		* Note: you can await
		* {@link workbox-strategies.StrategyHandler~doneWaiting}
		* to know when all added promises have settled.
		*
		* @param {Promise} promise A promise to add to the extend lifetime promises
		*     of the event that triggered the request.
		*/
		waitUntil(promise) {
			this._extendLifetimePromises.push(promise);
			return promise;
		}
		/**
		* Returns a promise that resolves once all promises passed to
		* {@link workbox-strategies.StrategyHandler~waitUntil}
		* have settled.
		*
		* Note: any work done after `doneWaiting()` settles should be manually
		* passed to an event's `waitUntil()` method (not this handler's
		* `waitUntil()` method), otherwise the service worker thread may be killed
		* prior to your work completing.
		*/
		async doneWaiting() {
			while (this._extendLifetimePromises.length) {
				const promises = this._extendLifetimePromises.splice(0);
				const firstRejection = (await Promise.allSettled(promises)).find((i) => i.status === "rejected");
				if (firstRejection) throw firstRejection.reason;
			}
		}
		/**
		* Stops running the strategy and immediately resolves any pending
		* `waitUntil()` promises.
		*/
		destroy() {
			this._handlerDeferred.resolve(null);
		}
		/**
		* This method will call cacheWillUpdate on the available plugins (or use
		* status === 200) to determine if the Response is safe and valid to cache.
		*
		* @param {Request} options.request
		* @param {Response} options.response
		* @return {Promise<Response|undefined>}
		*
		* @private
		*/
		async _ensureResponseSafeToCache(response) {
			let responseToCache = response;
			let pluginsUsed = false;
			for (const callback of this.iterateCallbacks("cacheWillUpdate")) {
				responseToCache = await callback({
					request: this.request,
					response: responseToCache,
					event: this.event
				}) || void 0;
				pluginsUsed = true;
				if (!responseToCache) break;
			}
			if (!pluginsUsed) {
				if (responseToCache && responseToCache.status !== 200) responseToCache = void 0;
			}
			return responseToCache;
		}
	};
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-strategies@7.4.1/node_modules/workbox-strategies/Strategy.js
	/**
	* An abstract base class that all other strategy classes must extend from:
	*
	* @memberof workbox-strategies
	*/
	var Strategy = class {
		/**
		* Creates a new instance of the strategy and sets all documented option
		* properties as public instance properties.
		*
		* Note: if a custom strategy class extends the base Strategy class and does
		* not need more than these properties, it does not need to define its own
		* constructor.
		*
		* @param {Object} [options]
		* @param {string} [options.cacheName] Cache name to store and retrieve
		* requests. Defaults to the cache names provided by
		* {@link workbox-core.cacheNames}.
		* @param {Array<Object>} [options.plugins] [Plugins]{@link https://developers.google.com/web/tools/workbox/guides/using-plugins}
		* to use in conjunction with this caching strategy.
		* @param {Object} [options.fetchOptions] Values passed along to the
		* [`init`](https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters)
		* of [non-navigation](https://github.com/GoogleChrome/workbox/issues/1796)
		* `fetch()` requests made by this strategy.
		* @param {Object} [options.matchOptions] The
		* [`CacheQueryOptions`]{@link https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions}
		* for any `cache.match()` or `cache.put()` calls made by this strategy.
		*/
		constructor(options = {}) {
			/**
			* Cache name to store and retrieve
			* requests. Defaults to the cache names provided by
			* {@link workbox-core.cacheNames}.
			*
			* @type {string}
			*/
			this.cacheName = cacheNames.getRuntimeName(options.cacheName);
			/**
			* The list
			* [Plugins]{@link https://developers.google.com/web/tools/workbox/guides/using-plugins}
			* used by this strategy.
			*
			* @type {Array<Object>}
			*/
			this.plugins = options.plugins || [];
			/**
			* Values passed along to the
			* [`init`]{@link https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters}
			* of all fetch() requests made by this strategy.
			*
			* @type {Object}
			*/
			this.fetchOptions = options.fetchOptions;
			/**
			* The
			* [`CacheQueryOptions`]{@link https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions}
			* for any `cache.match()` or `cache.put()` calls made by this strategy.
			*
			* @type {Object}
			*/
			this.matchOptions = options.matchOptions;
		}
		/**
		* Perform a request strategy and returns a `Promise` that will resolve with
		* a `Response`, invoking all relevant plugin callbacks.
		*
		* When a strategy instance is registered with a Workbox
		* {@link workbox-routing.Route}, this method is automatically
		* called when the route matches.
		*
		* Alternatively, this method can be used in a standalone `FetchEvent`
		* listener by passing it to `event.respondWith()`.
		*
		* @param {FetchEvent|Object} options A `FetchEvent` or an object with the
		*     properties listed below.
		* @param {Request|string} options.request A request to run this strategy for.
		* @param {ExtendableEvent} options.event The event associated with the
		*     request.
		* @param {URL} [options.url]
		* @param {*} [options.params]
		*/
		handle(options) {
			const [responseDone] = this.handleAll(options);
			return responseDone;
		}
		/**
		* Similar to {@link workbox-strategies.Strategy~handle}, but
		* instead of just returning a `Promise` that resolves to a `Response` it
		* it will return an tuple of `[response, done]` promises, where the former
		* (`response`) is equivalent to what `handle()` returns, and the latter is a
		* Promise that will resolve once any promises that were added to
		* `event.waitUntil()` as part of performing the strategy have completed.
		*
		* You can await the `done` promise to ensure any extra work performed by
		* the strategy (usually caching responses) completes successfully.
		*
		* @param {FetchEvent|Object} options A `FetchEvent` or an object with the
		*     properties listed below.
		* @param {Request|string} options.request A request to run this strategy for.
		* @param {ExtendableEvent} options.event The event associated with the
		*     request.
		* @param {URL} [options.url]
		* @param {*} [options.params]
		* @return {Array<Promise>} A tuple of [response, done]
		*     promises that can be used to determine when the response resolves as
		*     well as when the handler has completed all its work.
		*/
		handleAll(options) {
			if (options instanceof FetchEvent) options = {
				event: options,
				request: options.request
			};
			const event = options.event;
			const request = typeof options.request === "string" ? new Request(options.request) : options.request;
			const params = "params" in options ? options.params : void 0;
			const handler = new StrategyHandler(this, {
				event,
				request,
				params
			});
			const responseDone = this._getResponse(handler, request, event);
			return [responseDone, this._awaitComplete(responseDone, handler, request, event)];
		}
		async _getResponse(handler, request, event) {
			await handler.runCallbacks("handlerWillStart", {
				event,
				request
			});
			let response = void 0;
			try {
				response = await this._handle(request, handler);
				if (!response || response.type === "error") throw new WorkboxError("no-response", { url: request.url });
			} catch (error) {
				if (error instanceof Error) for (const callback of handler.iterateCallbacks("handlerDidError")) {
					response = await callback({
						error,
						event,
						request
					});
					if (response) break;
				}
				if (!response) throw error;
			}
			for (const callback of handler.iterateCallbacks("handlerWillRespond")) response = await callback({
				event,
				request,
				response
			});
			return response;
		}
		async _awaitComplete(responseDone, handler, request, event) {
			let response;
			let error;
			try {
				response = await responseDone;
			} catch (error) {}
			try {
				await handler.runCallbacks("handlerDidRespond", {
					event,
					request,
					response
				});
				await handler.doneWaiting();
			} catch (waitUntilError) {
				if (waitUntilError instanceof Error) error = waitUntilError;
			}
			await handler.runCallbacks("handlerDidComplete", {
				event,
				request,
				response,
				error
			});
			handler.destroy();
			if (error) throw error;
		}
	};
	/**
	* Classes extending the `Strategy` based class should implement this method,
	* and leverage the {@link workbox-strategies.StrategyHandler}
	* arg to perform all fetching and cache logic, which will ensure all relevant
	* cache, cache options, fetch options and plugins are used (per the current
	* strategy instance).
	*
	* @name _handle
	* @instance
	* @abstract
	* @function
	* @param {Request} request
	* @param {workbox-strategies.StrategyHandler} handler
	* @return {Promise<Response>}
	*
	* @memberof workbox-strategies.Strategy
	*/
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-precaching@7.4.1/node_modules/workbox-precaching/PrecacheStrategy.js
	/**
	* A {@link workbox-strategies.Strategy} implementation
	* specifically designed to work with
	* {@link workbox-precaching.PrecacheController}
	* to both cache and fetch precached assets.
	*
	* Note: an instance of this class is created automatically when creating a
	* `PrecacheController`; it's generally not necessary to create this yourself.
	*
	* @extends workbox-strategies.Strategy
	* @memberof workbox-precaching
	*/
	var PrecacheStrategy = class PrecacheStrategy extends Strategy {
		/**
		*
		* @param {Object} [options]
		* @param {string} [options.cacheName] Cache name to store and retrieve
		* requests. Defaults to the cache names provided by
		* {@link workbox-core.cacheNames}.
		* @param {Array<Object>} [options.plugins] {@link https://developers.google.com/web/tools/workbox/guides/using-plugins|Plugins}
		* to use in conjunction with this caching strategy.
		* @param {Object} [options.fetchOptions] Values passed along to the
		* {@link https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters|init}
		* of all fetch() requests made by this strategy.
		* @param {Object} [options.matchOptions] The
		* {@link https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions|CacheQueryOptions}
		* for any `cache.match()` or `cache.put()` calls made by this strategy.
		* @param {boolean} [options.fallbackToNetwork=true] Whether to attempt to
		* get the response from the network if there's a precache miss.
		*/
		constructor(options = {}) {
			options.cacheName = cacheNames.getPrecacheName(options.cacheName);
			super(options);
			this._fallbackToNetwork = options.fallbackToNetwork === false ? false : true;
			this.plugins.push(PrecacheStrategy.copyRedirectedCacheableResponsesPlugin);
		}
		/**
		* @private
		* @param {Request|string} request A request to run this strategy for.
		* @param {workbox-strategies.StrategyHandler} handler The event that
		*     triggered the request.
		* @return {Promise<Response>}
		*/
		async _handle(request, handler) {
			const response = await handler.cacheMatch(request);
			if (response) return response;
			if (handler.event && handler.event.type === "install") return await this._handleInstall(request, handler);
			return await this._handleFetch(request, handler);
		}
		async _handleFetch(request, handler) {
			let response;
			const params = handler.params || {};
			if (this._fallbackToNetwork) {
				const integrityInManifest = params.integrity;
				const integrityInRequest = request.integrity;
				const noIntegrityConflict = !integrityInRequest || integrityInRequest === integrityInManifest;
				response = await handler.fetch(new Request(request, { integrity: request.mode !== "no-cors" ? integrityInRequest || integrityInManifest : void 0 }));
				if (integrityInManifest && noIntegrityConflict && request.mode !== "no-cors") {
					this._useDefaultCacheabilityPluginIfNeeded();
					await handler.cachePut(request, response.clone());
				}
			} else throw new WorkboxError("missing-precache-entry", {
				cacheName: this.cacheName,
				url: request.url
			});
			return response;
		}
		async _handleInstall(request, handler) {
			this._useDefaultCacheabilityPluginIfNeeded();
			const response = await handler.fetch(request);
			if (!await handler.cachePut(request, response.clone())) throw new WorkboxError("bad-precaching-response", {
				url: request.url,
				status: response.status
			});
			return response;
		}
		/**
		* This method is complex, as there a number of things to account for:
		*
		* The `plugins` array can be set at construction, and/or it might be added to
		* to at any time before the strategy is used.
		*
		* At the time the strategy is used (i.e. during an `install` event), there
		* needs to be at least one plugin that implements `cacheWillUpdate` in the
		* array, other than `copyRedirectedCacheableResponsesPlugin`.
		*
		* - If this method is called and there are no suitable `cacheWillUpdate`
		* plugins, we need to add `defaultPrecacheCacheabilityPlugin`.
		*
		* - If this method is called and there is exactly one `cacheWillUpdate`, then
		* we don't have to do anything (this might be a previously added
		* `defaultPrecacheCacheabilityPlugin`, or it might be a custom plugin).
		*
		* - If this method is called and there is more than one `cacheWillUpdate`,
		* then we need to check if one is `defaultPrecacheCacheabilityPlugin`. If so,
		* we need to remove it. (This situation is unlikely, but it could happen if
		* the strategy is used multiple times, the first without a `cacheWillUpdate`,
		* and then later on after manually adding a custom `cacheWillUpdate`.)
		*
		* See https://github.com/GoogleChrome/workbox/issues/2737 for more context.
		*
		* @private
		*/
		_useDefaultCacheabilityPluginIfNeeded() {
			let defaultPluginIndex = null;
			let cacheWillUpdatePluginCount = 0;
			for (const [index, plugin] of this.plugins.entries()) {
				if (plugin === PrecacheStrategy.copyRedirectedCacheableResponsesPlugin) continue;
				if (plugin === PrecacheStrategy.defaultPrecacheCacheabilityPlugin) defaultPluginIndex = index;
				if (plugin.cacheWillUpdate) cacheWillUpdatePluginCount++;
			}
			if (cacheWillUpdatePluginCount === 0) this.plugins.push(PrecacheStrategy.defaultPrecacheCacheabilityPlugin);
			else if (cacheWillUpdatePluginCount > 1 && defaultPluginIndex !== null) this.plugins.splice(defaultPluginIndex, 1);
		}
	};
	PrecacheStrategy.defaultPrecacheCacheabilityPlugin = { async cacheWillUpdate({ response }) {
		if (!response || response.status >= 400) return null;
		return response;
	} };
	PrecacheStrategy.copyRedirectedCacheableResponsesPlugin = { async cacheWillUpdate({ response }) {
		return response.redirected ? await copyResponse(response) : response;
	} };
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-precaching@7.4.1/node_modules/workbox-precaching/PrecacheController.js
	/**
	* Performs efficient precaching of assets.
	*
	* @memberof workbox-precaching
	*/
	var PrecacheController = class {
		/**
		* Create a new PrecacheController.
		*
		* @param {Object} [options]
		* @param {string} [options.cacheName] The cache to use for precaching.
		* @param {string} [options.plugins] Plugins to use when precaching as well
		* as responding to fetch events for precached assets.
		* @param {boolean} [options.fallbackToNetwork=true] Whether to attempt to
		* get the response from the network if there's a precache miss.
		*/
		constructor({ cacheName, plugins = [], fallbackToNetwork = true } = {}) {
			this._urlsToCacheKeys = /* @__PURE__ */ new Map();
			this._urlsToCacheModes = /* @__PURE__ */ new Map();
			this._cacheKeysToIntegrities = /* @__PURE__ */ new Map();
			this._strategy = new PrecacheStrategy({
				cacheName: cacheNames.getPrecacheName(cacheName),
				plugins: [...plugins, new PrecacheCacheKeyPlugin({ precacheController: this })],
				fallbackToNetwork
			});
			this.install = this.install.bind(this);
			this.activate = this.activate.bind(this);
		}
		/**
		* @type {workbox-precaching.PrecacheStrategy} The strategy created by this controller and
		* used to cache assets and respond to fetch events.
		*/
		get strategy() {
			return this._strategy;
		}
		/**
		* Adds items to the precache list, removing any duplicates and
		* stores the files in the
		* {@link workbox-core.cacheNames|"precache cache"} when the service
		* worker installs.
		*
		* This method can be called multiple times.
		*
		* @param {Array<Object|string>} [entries=[]] Array of entries to precache.
		*/
		precache(entries) {
			this.addToCacheList(entries);
			if (!this._installAndActiveListenersAdded) {
				self.addEventListener("install", this.install);
				self.addEventListener("activate", this.activate);
				this._installAndActiveListenersAdded = true;
			}
		}
		/**
		* This method will add items to the precache list, removing duplicates
		* and ensuring the information is valid.
		*
		* @param {Array<workbox-precaching.PrecacheController.PrecacheEntry|string>} entries
		*     Array of entries to precache.
		*/
		addToCacheList(entries) {
			const urlsToWarnAbout = [];
			for (const entry of entries) {
				if (typeof entry === "string") urlsToWarnAbout.push(entry);
				else if (entry && entry.revision === void 0) urlsToWarnAbout.push(entry.url);
				const { cacheKey, url } = createCacheKey(entry);
				const cacheMode = typeof entry !== "string" && entry.revision ? "reload" : "default";
				if (this._urlsToCacheKeys.has(url) && this._urlsToCacheKeys.get(url) !== cacheKey) throw new WorkboxError("add-to-cache-list-conflicting-entries", {
					firstEntry: this._urlsToCacheKeys.get(url),
					secondEntry: cacheKey
				});
				if (typeof entry !== "string" && entry.integrity) {
					if (this._cacheKeysToIntegrities.has(cacheKey) && this._cacheKeysToIntegrities.get(cacheKey) !== entry.integrity) throw new WorkboxError("add-to-cache-list-conflicting-integrities", { url });
					this._cacheKeysToIntegrities.set(cacheKey, entry.integrity);
				}
				this._urlsToCacheKeys.set(url, cacheKey);
				this._urlsToCacheModes.set(url, cacheMode);
				if (urlsToWarnAbout.length > 0) {
					const warningMessage = `Workbox is precaching URLs without revision info: ${urlsToWarnAbout.join(", ")}\nThis is generally NOT safe. Learn more at https://bit.ly/wb-precache`;
					console.warn(warningMessage);
				}
			}
		}
		/**
		* Precaches new and updated assets. Call this method from the service worker
		* install event.
		*
		* Note: this method calls `event.waitUntil()` for you, so you do not need
		* to call it yourself in your event handlers.
		*
		* @param {ExtendableEvent} event
		* @return {Promise<workbox-precaching.InstallResult>}
		*/
		install(event) {
			return waitUntil(event, async () => {
				const installReportPlugin = new PrecacheInstallReportPlugin();
				this.strategy.plugins.push(installReportPlugin);
				for (const [url, cacheKey] of this._urlsToCacheKeys) {
					const integrity = this._cacheKeysToIntegrities.get(cacheKey);
					const cacheMode = this._urlsToCacheModes.get(url);
					const request = new Request(url, {
						integrity,
						cache: cacheMode,
						credentials: "same-origin"
					});
					await Promise.all(this.strategy.handleAll({
						params: { cacheKey },
						request,
						event
					}));
				}
				const { updatedURLs, notUpdatedURLs } = installReportPlugin;
				return {
					updatedURLs,
					notUpdatedURLs
				};
			});
		}
		/**
		* Deletes assets that are no longer present in the current precache manifest.
		* Call this method from the service worker activate event.
		*
		* Note: this method calls `event.waitUntil()` for you, so you do not need
		* to call it yourself in your event handlers.
		*
		* @param {ExtendableEvent} event
		* @return {Promise<workbox-precaching.CleanupResult>}
		*/
		activate(event) {
			return waitUntil(event, async () => {
				const cache = await self.caches.open(this.strategy.cacheName);
				const currentlyCachedRequests = await cache.keys();
				const expectedCacheKeys = new Set(this._urlsToCacheKeys.values());
				const deletedURLs = [];
				for (const request of currentlyCachedRequests) if (!expectedCacheKeys.has(request.url)) {
					await cache.delete(request);
					deletedURLs.push(request.url);
				}
				return { deletedURLs };
			});
		}
		/**
		* Returns a mapping of a precached URL to the corresponding cache key, taking
		* into account the revision information for the URL.
		*
		* @return {Map<string, string>} A URL to cache key mapping.
		*/
		getURLsToCacheKeys() {
			return this._urlsToCacheKeys;
		}
		/**
		* Returns a list of all the URLs that have been precached by the current
		* service worker.
		*
		* @return {Array<string>} The precached URLs.
		*/
		getCachedURLs() {
			return [...this._urlsToCacheKeys.keys()];
		}
		/**
		* Returns the cache key used for storing a given URL. If that URL is
		* unversioned, like `/index.html', then the cache key will be the original
		* URL with a search parameter appended to it.
		*
		* @param {string} url A URL whose cache key you want to look up.
		* @return {string} The versioned URL that corresponds to a cache key
		* for the original URL, or undefined if that URL isn't precached.
		*/
		getCacheKeyForURL(url) {
			const urlObject = new URL(url, location.href);
			return this._urlsToCacheKeys.get(urlObject.href);
		}
		/**
		* @param {string} url A cache key whose SRI you want to look up.
		* @return {string} The subresource integrity associated with the cache key,
		* or undefined if it's not set.
		*/
		getIntegrityForCacheKey(cacheKey) {
			return this._cacheKeysToIntegrities.get(cacheKey);
		}
		/**
		* This acts as a drop-in replacement for
		* [`cache.match()`](https://developer.mozilla.org/en-US/docs/Web/API/Cache/match)
		* with the following differences:
		*
		* - It knows what the name of the precache is, and only checks in that cache.
		* - It allows you to pass in an "original" URL without versioning parameters,
		* and it will automatically look up the correct cache key for the currently
		* active revision of that URL.
		*
		* E.g., `matchPrecache('index.html')` will find the correct precached
		* response for the currently active service worker, even if the actual cache
		* key is `'/index.html?__WB_REVISION__=1234abcd'`.
		*
		* @param {string|Request} request The key (without revisioning parameters)
		* to look up in the precache.
		* @return {Promise<Response|undefined>}
		*/
		async matchPrecache(request) {
			const url = request instanceof Request ? request.url : request;
			const cacheKey = this.getCacheKeyForURL(url);
			if (cacheKey) return (await self.caches.open(this.strategy.cacheName)).match(cacheKey);
		}
		/**
		* Returns a function that looks up `url` in the precache (taking into
		* account revision information), and returns the corresponding `Response`.
		*
		* @param {string} url The precached URL which will be used to lookup the
		* `Response`.
		* @return {workbox-routing~handlerCallback}
		*/
		createHandlerBoundToURL(url) {
			const cacheKey = this.getCacheKeyForURL(url);
			if (!cacheKey) throw new WorkboxError("non-precached-url", { url });
			return (options) => {
				options.request = new Request(url);
				options.params = Object.assign({ cacheKey }, options.params);
				return this.strategy.handle(options);
			};
		}
	};
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-routing@7.4.1/node_modules/workbox-routing/_version.js
	try {
		self["workbox:routing:7.4.0"] && _();
	} catch (e) {}
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-precaching@7.4.1/node_modules/workbox-precaching/_types.js
	/**
	* @typedef {Object} InstallResult
	* @property {Array<string>} updatedURLs List of URLs that were updated during
	* installation.
	* @property {Array<string>} notUpdatedURLs List of URLs that were already up to
	* date.
	*
	* @memberof workbox-precaching
	*/
	/**
	* @typedef {Object} CleanupResult
	* @property {Array<string>} deletedCacheRequests List of URLs that were deleted
	* while cleaning up the cache.
	*
	* @memberof workbox-precaching
	*/
	/**
	* @typedef {Object} PrecacheEntry
	* @property {string} url URL to precache.
	* @property {string} [revision] Revision information for the URL.
	* @property {string} [integrity] Integrity metadata that will be used when
	* making the network request for the URL.
	*
	* @memberof workbox-precaching
	*/
	/**
	* The "urlManipulation" callback can be used to determine if there are any
	* additional permutations of a URL that should be used to check against
	* the available precached files.
	*
	* For example, Workbox supports checking for '/index.html' when the URL
	* '/' is provided. This callback allows additional, custom checks.
	*
	* @callback ~urlManipulation
	* @param {Object} context
	* @param {URL} context.url The request's URL.
	* @return {Array<URL>} To add additional urls to test, return an Array of
	* URLs. Please note that these **should not be strings**, but URL objects.
	*
	* @memberof workbox-precaching
	*/
	//#endregion
	//#region ../engine-workbox/dist/worker/options.js
	var CACHE_NAME_PREFIX = "pwa:";
	var CACHE_NAME_SUFFIX = ":precache";
	var PATH_BASE$1 = "https://engine-workbox.invalid/";
	/** Validates engine options and returns a fresh copy. Messages name fields and indexes, never input values. */
	function validatePrecacheEngineOptions(options) {
		if (!isRecord(options)) throw new TypeError("Precache engine options must be an object");
		const { cacheName, entries } = options;
		if (!(typeof cacheName === "string" && cacheName.startsWith(CACHE_NAME_PREFIX) && cacheName.endsWith(CACHE_NAME_SUFFIX) && cacheName.length > 13)) throw new Error("cacheName must be a contracts precache cache name of the form \"pwa:<…>:precache\"");
		if (!Array.isArray(entries)) throw new TypeError("entries must be an array");
		const seen = /* @__PURE__ */ new Set();
		return {
			cacheName,
			entries: entries.map((entry, index) => {
				if (!isRecord(entry)) throw new TypeError(`entries[${index}] must be an object`);
				const keys = Object.keys(entry).sort();
				if (keys.length !== 2 || keys[0] !== "revision" || keys[1] !== "url") throw new Error(`entries[${index}] must have exactly the fields url and revision`);
				const { url, revision } = entry;
				if (typeof url !== "string" || !isCanonicalPath(url)) throw new Error(`entries[${index}].url must be a canonical same-origin absolute path: no query, fragment, dot segments, "//", backslashes or characters the URL parser would change`);
				if (revision !== null && (typeof revision !== "string" || revision === "")) throw new Error(`entries[${index}].revision must be a non-empty string or null`);
				if (seen.has(url)) throw new Error(`entries[${index}].url duplicates an earlier entry`);
				seen.add(url);
				return {
					url,
					revision
				};
			})
		};
	}
	/**
	* The rule contracts' `isCanonicalPath` applies to `PwaPlan.precache` URLs, repeated here because the worker entry
	* does not import contracts. The URL parser treats `\` as `/` and drops tabs and newlines, so without the final
	* comparison `/\evil.example/a.js` would resolve to another origin.
	*/
	function isCanonicalPath(value) {
		return value.startsWith("/") && !value.includes("//") && !value.includes("\\") && URL.canParse(value, PATH_BASE$1) && new URL(value, PATH_BASE$1).pathname === value;
	}
	/** Resolves `url` against `base` and drops the fragment; the query string is kept, so matching stays exact. */
	function resolveManifestUrl(url, base) {
		const resolved = new URL(url, base);
		resolved.hash = "";
		return resolved.href;
	}
	function isRecord(value) {
		return typeof value === "object" && value !== null && !Array.isArray(value);
	}
	//#endregion
	//#region ../engine-workbox/dist/worker/engine.js
	/**
	* Creates the precache port for one plan. It registers no event listeners, never calls `skipWaiting` or
	* `clients.claim`, and touches no cache other than `cacheName`.
	*/
	function createPrecacheEngine(options) {
		const { cacheName, entries } = validatePrecacheEngineOptions(options);
		const controller = new PrecacheController({
			cacheName,
			fallbackToNetwork: false
		});
		controller.addToCacheList(entries.map(({ url, revision }) => ({
			url,
			revision
		})));
		const urls = entries.map(({ url }) => url);
		return {
			async install(event) {
				const { updatedURLs, notUpdatedURLs } = await controller.install(event);
				return {
					updatedUrls: [...updatedURLs],
					notUpdatedUrls: [...notUpdatedURLs]
				};
			},
			async activate(event) {
				const { deletedURLs } = await controller.activate(event);
				if (!Array.isArray(deletedURLs) || !deletedURLs.every((url) => typeof url === "string")) throw new Error("Workbox did not report the deleted precache requests");
				return { deletedUrls: [...deletedURLs] };
			},
			async match(url) {
				if (!URL.canParse(url, self.location.href)) return void 0;
				const cacheKey = controller.getCacheKeyForURL(resolveManifestUrl(url, self.location.href));
				if (cacheKey === void 0) return void 0;
				return await self.caches.match(cacheKey, { cacheName }) ?? void 0;
			},
			urls() {
				return [...urls];
			}
		};
	}
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-core@7.4.1/node_modules/workbox-core/registerQuotaErrorCallback.js
	/**
	* Adds a function to the set of quotaErrorCallbacks that will be executed if
	* there's a quota error.
	*
	* @param {Function} callback
	* @memberof workbox-core
	*/
	function registerQuotaErrorCallback(callback) {
		quotaErrorCallbacks.add(callback);
	}
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-core@7.4.1/node_modules/workbox-core/_private/dontWaitFor.js
	/**
	* A helper function that prevents a promise from being flagged as unused.
	*
	* @private
	**/
	function dontWaitFor(promise) {
		promise.then(() => {});
	}
	//#endregion
	//#region ../../node_modules/.pnpm/idb@7.1.1/node_modules/idb/build/wrap-idb-value.js
	var instanceOfAny = (object, constructors) => constructors.some((c) => object instanceof c);
	var idbProxyableTypes;
	var cursorAdvanceMethods;
	function getIdbProxyableTypes() {
		return idbProxyableTypes || (idbProxyableTypes = [
			IDBDatabase,
			IDBObjectStore,
			IDBIndex,
			IDBCursor,
			IDBTransaction
		]);
	}
	function getCursorAdvanceMethods() {
		return cursorAdvanceMethods || (cursorAdvanceMethods = [
			IDBCursor.prototype.advance,
			IDBCursor.prototype.continue,
			IDBCursor.prototype.continuePrimaryKey
		]);
	}
	var cursorRequestMap = /* @__PURE__ */ new WeakMap();
	var transactionDoneMap = /* @__PURE__ */ new WeakMap();
	var transactionStoreNamesMap = /* @__PURE__ */ new WeakMap();
	var transformCache = /* @__PURE__ */ new WeakMap();
	var reverseTransformCache = /* @__PURE__ */ new WeakMap();
	function promisifyRequest(request) {
		const promise = new Promise((resolve, reject) => {
			const unlisten = () => {
				request.removeEventListener("success", success);
				request.removeEventListener("error", error);
			};
			const success = () => {
				resolve(wrap(request.result));
				unlisten();
			};
			const error = () => {
				reject(request.error);
				unlisten();
			};
			request.addEventListener("success", success);
			request.addEventListener("error", error);
		});
		promise.then((value) => {
			if (value instanceof IDBCursor) cursorRequestMap.set(value, request);
		}).catch(() => {});
		reverseTransformCache.set(promise, request);
		return promise;
	}
	function cacheDonePromiseForTransaction(tx) {
		if (transactionDoneMap.has(tx)) return;
		const done = new Promise((resolve, reject) => {
			const unlisten = () => {
				tx.removeEventListener("complete", complete);
				tx.removeEventListener("error", error);
				tx.removeEventListener("abort", error);
			};
			const complete = () => {
				resolve();
				unlisten();
			};
			const error = () => {
				reject(tx.error || new DOMException("AbortError", "AbortError"));
				unlisten();
			};
			tx.addEventListener("complete", complete);
			tx.addEventListener("error", error);
			tx.addEventListener("abort", error);
		});
		transactionDoneMap.set(tx, done);
	}
	var idbProxyTraps = {
		get(target, prop, receiver) {
			if (target instanceof IDBTransaction) {
				if (prop === "done") return transactionDoneMap.get(target);
				if (prop === "objectStoreNames") return target.objectStoreNames || transactionStoreNamesMap.get(target);
				if (prop === "store") return receiver.objectStoreNames[1] ? void 0 : receiver.objectStore(receiver.objectStoreNames[0]);
			}
			return wrap(target[prop]);
		},
		set(target, prop, value) {
			target[prop] = value;
			return true;
		},
		has(target, prop) {
			if (target instanceof IDBTransaction && (prop === "done" || prop === "store")) return true;
			return prop in target;
		}
	};
	function replaceTraps(callback) {
		idbProxyTraps = callback(idbProxyTraps);
	}
	function wrapFunction(func) {
		if (func === IDBDatabase.prototype.transaction && !("objectStoreNames" in IDBTransaction.prototype)) return function(storeNames, ...args) {
			const tx = func.call(unwrap(this), storeNames, ...args);
			transactionStoreNamesMap.set(tx, storeNames.sort ? storeNames.sort() : [storeNames]);
			return wrap(tx);
		};
		if (getCursorAdvanceMethods().includes(func)) return function(...args) {
			func.apply(unwrap(this), args);
			return wrap(cursorRequestMap.get(this));
		};
		return function(...args) {
			return wrap(func.apply(unwrap(this), args));
		};
	}
	function transformCachableValue(value) {
		if (typeof value === "function") return wrapFunction(value);
		if (value instanceof IDBTransaction) cacheDonePromiseForTransaction(value);
		if (instanceOfAny(value, getIdbProxyableTypes())) return new Proxy(value, idbProxyTraps);
		return value;
	}
	function wrap(value) {
		if (value instanceof IDBRequest) return promisifyRequest(value);
		if (transformCache.has(value)) return transformCache.get(value);
		const newValue = transformCachableValue(value);
		if (newValue !== value) {
			transformCache.set(value, newValue);
			reverseTransformCache.set(newValue, value);
		}
		return newValue;
	}
	var unwrap = (value) => reverseTransformCache.get(value);
	//#endregion
	//#region ../../node_modules/.pnpm/idb@7.1.1/node_modules/idb/build/index.js
	/**
	* Open a database.
	*
	* @param name Name of the database.
	* @param version Schema version.
	* @param callbacks Additional callbacks.
	*/
	function openDB(name, version, { blocked, upgrade, blocking, terminated } = {}) {
		const request = indexedDB.open(name, version);
		const openPromise = wrap(request);
		if (upgrade) request.addEventListener("upgradeneeded", (event) => {
			upgrade(wrap(request.result), event.oldVersion, event.newVersion, wrap(request.transaction), event);
		});
		if (blocked) request.addEventListener("blocked", (event) => blocked(event.oldVersion, event.newVersion, event));
		openPromise.then((db) => {
			if (terminated) db.addEventListener("close", () => terminated());
			if (blocking) db.addEventListener("versionchange", (event) => blocking(event.oldVersion, event.newVersion, event));
		}).catch(() => {});
		return openPromise;
	}
	/**
	* Delete a database.
	*
	* @param name Name of the database.
	*/
	function deleteDB(name, { blocked } = {}) {
		const request = indexedDB.deleteDatabase(name);
		if (blocked) request.addEventListener("blocked", (event) => blocked(event.oldVersion, event));
		return wrap(request).then(() => void 0);
	}
	var readMethods = [
		"get",
		"getKey",
		"getAll",
		"getAllKeys",
		"count"
	];
	var writeMethods = [
		"put",
		"add",
		"delete",
		"clear"
	];
	var cachedMethods = /* @__PURE__ */ new Map();
	function getMethod(target, prop) {
		if (!(target instanceof IDBDatabase && !(prop in target) && typeof prop === "string")) return;
		if (cachedMethods.get(prop)) return cachedMethods.get(prop);
		const targetFuncName = prop.replace(/FromIndex$/, "");
		const useIndex = prop !== targetFuncName;
		const isWrite = writeMethods.includes(targetFuncName);
		if (!(targetFuncName in (useIndex ? IDBIndex : IDBObjectStore).prototype) || !(isWrite || readMethods.includes(targetFuncName))) return;
		const method = async function(storeName, ...args) {
			const tx = this.transaction(storeName, isWrite ? "readwrite" : "readonly");
			let target = tx.store;
			if (useIndex) target = target.index(args.shift());
			return (await Promise.all([target[targetFuncName](...args), isWrite && tx.done]))[0];
		};
		cachedMethods.set(prop, method);
		return method;
	}
	replaceTraps((oldTraps) => ({
		...oldTraps,
		get: (target, prop, receiver) => getMethod(target, prop) || oldTraps.get(target, prop, receiver),
		has: (target, prop) => !!getMethod(target, prop) || oldTraps.has(target, prop)
	}));
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-expiration@7.4.1/node_modules/workbox-expiration/_version.js
	try {
		self["workbox:expiration:7.4.0"] && _();
	} catch (e) {}
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-expiration@7.4.1/node_modules/workbox-expiration/models/CacheTimestampsModel.js
	var DB_NAME = "workbox-expiration";
	var CACHE_OBJECT_STORE = "cache-entries";
	var normalizeURL = (unNormalizedUrl) => {
		const url = new URL(unNormalizedUrl, location.href);
		url.hash = "";
		return url.href;
	};
	/**
	* Returns the timestamp model.
	*
	* @private
	*/
	var CacheTimestampsModel = class {
		/**
		*
		* @param {string} cacheName
		*
		* @private
		*/
		constructor(cacheName) {
			this._db = null;
			this._cacheName = cacheName;
		}
		/**
		* Performs an upgrade of indexedDB.
		*
		* @param {IDBPDatabase<CacheDbSchema>} db
		*
		* @private
		*/
		_upgradeDb(db) {
			const objStore = db.createObjectStore(CACHE_OBJECT_STORE, { keyPath: "id" });
			objStore.createIndex("cacheName", "cacheName", { unique: false });
			objStore.createIndex("timestamp", "timestamp", { unique: false });
		}
		/**
		* Performs an upgrade of indexedDB and deletes deprecated DBs.
		*
		* @param {IDBPDatabase<CacheDbSchema>} db
		*
		* @private
		*/
		_upgradeDbAndDeleteOldDbs(db) {
			this._upgradeDb(db);
			if (this._cacheName) deleteDB(this._cacheName);
		}
		/**
		* @param {string} url
		* @param {number} timestamp
		*
		* @private
		*/
		async setTimestamp(url, timestamp) {
			url = normalizeURL(url);
			const entry = {
				url,
				timestamp,
				cacheName: this._cacheName,
				id: this._getId(url)
			};
			const tx = (await this.getDb()).transaction(CACHE_OBJECT_STORE, "readwrite", { durability: "relaxed" });
			await tx.store.put(entry);
			await tx.done;
		}
		/**
		* Returns the timestamp stored for a given URL.
		*
		* @param {string} url
		* @return {number | undefined}
		*
		* @private
		*/
		async getTimestamp(url) {
			const entry = await (await this.getDb()).get(CACHE_OBJECT_STORE, this._getId(url));
			return entry === null || entry === void 0 ? void 0 : entry.timestamp;
		}
		/**
		* Iterates through all the entries in the object store (from newest to
		* oldest) and removes entries once either `maxCount` is reached or the
		* entry's timestamp is less than `minTimestamp`.
		*
		* @param {number} minTimestamp
		* @param {number} maxCount
		* @return {Array<string>}
		*
		* @private
		*/
		async expireEntries(minTimestamp, maxCount) {
			const db = await this.getDb();
			let cursor = await db.transaction(CACHE_OBJECT_STORE).store.index("timestamp").openCursor(null, "prev");
			const entriesToDelete = [];
			let entriesNotDeletedCount = 0;
			while (cursor) {
				const result = cursor.value;
				if (result.cacheName === this._cacheName) {
					if (minTimestamp && result.timestamp < minTimestamp || maxCount && entriesNotDeletedCount >= maxCount) entriesToDelete.push(cursor.value);
					else entriesNotDeletedCount++;
				}
				cursor = await cursor.continue();
			}
			const urlsDeleted = [];
			for (const entry of entriesToDelete) {
				await db.delete(CACHE_OBJECT_STORE, entry.id);
				urlsDeleted.push(entry.url);
			}
			return urlsDeleted;
		}
		/**
		* Takes a URL and returns an ID that will be unique in the object store.
		*
		* @param {string} url
		* @return {string}
		*
		* @private
		*/
		_getId(url) {
			return this._cacheName + "|" + normalizeURL(url);
		}
		/**
		* Returns an open connection to the database.
		*
		* @private
		*/
		async getDb() {
			if (!this._db) this._db = await openDB(DB_NAME, 1, { upgrade: this._upgradeDbAndDeleteOldDbs.bind(this) });
			return this._db;
		}
	};
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-expiration@7.4.1/node_modules/workbox-expiration/CacheExpiration.js
	/**
	* The `CacheExpiration` class allows you define an expiration and / or
	* limit on the number of responses stored in a
	* [`Cache`](https://developer.mozilla.org/en-US/docs/Web/API/Cache).
	*
	* @memberof workbox-expiration
	*/
	var CacheExpiration = class {
		/**
		* To construct a new CacheExpiration instance you must provide at least
		* one of the `config` properties.
		*
		* @param {string} cacheName Name of the cache to apply restrictions to.
		* @param {Object} config
		* @param {number} [config.maxEntries] The maximum number of entries to cache.
		* Entries used the least will be removed as the maximum is reached.
		* @param {number} [config.maxAgeSeconds] The maximum age of an entry before
		* it's treated as stale and removed.
		* @param {Object} [config.matchOptions] The [`CacheQueryOptions`](https://developer.mozilla.org/en-US/docs/Web/API/Cache/delete#Parameters)
		* that will be used when calling `delete()` on the cache.
		*/
		constructor(cacheName, config = {}) {
			this._isRunning = false;
			this._rerunRequested = false;
			this._maxEntries = config.maxEntries;
			this._maxAgeSeconds = config.maxAgeSeconds;
			this._matchOptions = config.matchOptions;
			this._cacheName = cacheName;
			this._timestampModel = new CacheTimestampsModel(cacheName);
		}
		/**
		* Expires entries for the given cache and given criteria.
		*/
		async expireEntries() {
			if (this._isRunning) {
				this._rerunRequested = true;
				return;
			}
			this._isRunning = true;
			const minTimestamp = this._maxAgeSeconds ? Date.now() - this._maxAgeSeconds * 1e3 : 0;
			const urlsExpired = await this._timestampModel.expireEntries(minTimestamp, this._maxEntries);
			const cache = await self.caches.open(this._cacheName);
			for (const url of urlsExpired) await cache.delete(url, this._matchOptions);
			this._isRunning = false;
			if (this._rerunRequested) {
				this._rerunRequested = false;
				dontWaitFor(this.expireEntries());
			}
		}
		/**
		* Update the timestamp for the given URL. This ensures the when
		* removing entries based on maximum entries, most recently used
		* is accurate or when expiring, the timestamp is up-to-date.
		*
		* @param {string} url
		*/
		async updateTimestamp(url) {
			await this._timestampModel.setTimestamp(url, Date.now());
		}
		/**
		* Can be used to check if a URL has expired or not before it's used.
		*
		* This requires a look up from IndexedDB, so can be slow.
		*
		* Note: This method will not remove the cached entry, call
		* `expireEntries()` to remove indexedDB and Cache entries.
		*
		* @param {string} url
		* @return {boolean}
		*/
		async isURLExpired(url) {
			if (!this._maxAgeSeconds) return false;
			else {
				const timestamp = await this._timestampModel.getTimestamp(url);
				const expireOlderThan = Date.now() - this._maxAgeSeconds * 1e3;
				return timestamp !== void 0 ? timestamp < expireOlderThan : true;
			}
		}
		/**
		* Removes the IndexedDB object store used to keep track of cache expiration
		* metadata.
		*/
		async delete() {
			this._rerunRequested = false;
			await this._timestampModel.expireEntries(Infinity);
		}
	};
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-expiration@7.4.1/node_modules/workbox-expiration/ExpirationPlugin.js
	/**
	* This plugin can be used in a `workbox-strategy` to regularly enforce a
	* limit on the age and / or the number of cached requests.
	*
	* It can only be used with `workbox-strategy` instances that have a
	* [custom `cacheName` property set](/web/tools/workbox/guides/configure-workbox#custom_cache_names_in_strategies).
	* In other words, it can't be used to expire entries in strategy that uses the
	* default runtime cache name.
	*
	* Whenever a cached response is used or updated, this plugin will look
	* at the associated cache and remove any old or extra responses.
	*
	* When using `maxAgeSeconds`, responses may be used *once* after expiring
	* because the expiration clean up will not have occurred until *after* the
	* cached response has been used. If the response has a "Date" header, then
	* a light weight expiration check is performed and the response will not be
	* used immediately.
	*
	* When using `maxEntries`, the entry least-recently requested will be removed
	* from the cache first.
	*
	* @memberof workbox-expiration
	*/
	var ExpirationPlugin = class {
		/**
		* @param {ExpirationPluginOptions} config
		* @param {number} [config.maxEntries] The maximum number of entries to cache.
		* Entries used the least will be removed as the maximum is reached.
		* @param {number} [config.maxAgeSeconds] The maximum age of an entry before
		* it's treated as stale and removed.
		* @param {Object} [config.matchOptions] The [`CacheQueryOptions`](https://developer.mozilla.org/en-US/docs/Web/API/Cache/delete#Parameters)
		* that will be used when calling `delete()` on the cache.
		* @param {boolean} [config.purgeOnQuotaError] Whether to opt this cache in to
		* automatic deletion if the available storage quota has been exceeded.
		*/
		constructor(config = {}) {
			/**
			* A "lifecycle" callback that will be triggered automatically by the
			* `workbox-strategies` handlers when a `Response` is about to be returned
			* from a [Cache](https://developer.mozilla.org/en-US/docs/Web/API/Cache) to
			* the handler. It allows the `Response` to be inspected for freshness and
			* prevents it from being used if the `Response`'s `Date` header value is
			* older than the configured `maxAgeSeconds`.
			*
			* @param {Object} options
			* @param {string} options.cacheName Name of the cache the response is in.
			* @param {Response} options.cachedResponse The `Response` object that's been
			*     read from a cache and whose freshness should be checked.
			* @return {Response} Either the `cachedResponse`, if it's
			*     fresh, or `null` if the `Response` is older than `maxAgeSeconds`.
			*
			* @private
			*/
			this.cachedResponseWillBeUsed = async ({ event, request, cacheName, cachedResponse }) => {
				if (!cachedResponse) return null;
				const isFresh = this._isResponseDateFresh(cachedResponse);
				const cacheExpiration = this._getCacheExpiration(cacheName);
				dontWaitFor(cacheExpiration.expireEntries());
				const updateTimestampDone = cacheExpiration.updateTimestamp(request.url);
				if (event) try {
					event.waitUntil(updateTimestampDone);
				} catch (error) {}
				return isFresh ? cachedResponse : null;
			};
			/**
			* A "lifecycle" callback that will be triggered automatically by the
			* `workbox-strategies` handlers when an entry is added to a cache.
			*
			* @param {Object} options
			* @param {string} options.cacheName Name of the cache that was updated.
			* @param {string} options.request The Request for the cached entry.
			*
			* @private
			*/
			this.cacheDidUpdate = async ({ cacheName, request }) => {
				const cacheExpiration = this._getCacheExpiration(cacheName);
				await cacheExpiration.updateTimestamp(request.url);
				await cacheExpiration.expireEntries();
			};
			this._config = config;
			this._maxAgeSeconds = config.maxAgeSeconds;
			this._cacheExpirations = /* @__PURE__ */ new Map();
			if (config.purgeOnQuotaError) registerQuotaErrorCallback(() => this.deleteCacheAndMetadata());
		}
		/**
		* A simple helper method to return a CacheExpiration instance for a given
		* cache name.
		*
		* @param {string} cacheName
		* @return {CacheExpiration}
		*
		* @private
		*/
		_getCacheExpiration(cacheName) {
			if (cacheName === cacheNames.getRuntimeName()) throw new WorkboxError("expire-custom-caches-only");
			let cacheExpiration = this._cacheExpirations.get(cacheName);
			if (!cacheExpiration) {
				cacheExpiration = new CacheExpiration(cacheName, this._config);
				this._cacheExpirations.set(cacheName, cacheExpiration);
			}
			return cacheExpiration;
		}
		/**
		* @param {Response} cachedResponse
		* @return {boolean}
		*
		* @private
		*/
		_isResponseDateFresh(cachedResponse) {
			if (!this._maxAgeSeconds) return true;
			const dateHeaderTimestamp = this._getDateHeaderTimestamp(cachedResponse);
			if (dateHeaderTimestamp === null) return true;
			return dateHeaderTimestamp >= Date.now() - this._maxAgeSeconds * 1e3;
		}
		/**
		* This method will extract the data header and parse it into a useful
		* value.
		*
		* @param {Response} cachedResponse
		* @return {number|null}
		*
		* @private
		*/
		_getDateHeaderTimestamp(cachedResponse) {
			if (!cachedResponse.headers.has("date")) return null;
			const dateHeader = cachedResponse.headers.get("date");
			const headerTime = new Date(dateHeader).getTime();
			if (isNaN(headerTime)) return null;
			return headerTime;
		}
		/**
		* This is a helper method that performs two operations:
		*
		* - Deletes *all* the underlying Cache instances associated with this plugin
		* instance, by calling caches.delete() on your behalf.
		* - Deletes the metadata from IndexedDB used to keep track of expiration
		* details for each Cache instance.
		*
		* When using cache expiration, calling this method is preferable to calling
		* `caches.delete()` directly, since this will ensure that the IndexedDB
		* metadata is also cleanly removed and open IndexedDB instances are deleted.
		*
		* Note that if you're *not* using cache expiration for a given cache, calling
		* `caches.delete()` and passing in the cache's name should be sufficient.
		* There is no Workbox-specific method needed for cleanup in that case.
		*/
		async deleteCacheAndMetadata() {
			for (const [cacheName, cacheExpiration] of this._cacheExpirations) {
				await self.caches.delete(cacheName);
				await cacheExpiration.delete();
			}
			this._cacheExpirations = /* @__PURE__ */ new Map();
		}
	};
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-strategies@7.4.1/node_modules/workbox-strategies/plugins/cacheOkAndOpaquePlugin.js
	var cacheOkAndOpaquePlugin = { 
	/**
	* Returns a valid response (to allow caching) if the status is 200 (OK) or
	* 0 (opaque).
	*
	* @param {Object} options
	* @param {Response} options.response
	* @return {Response|null}
	*
	* @private
	*/
cacheWillUpdate: async ({ response }) => {
		if (response.status === 200 || response.status === 0) return response;
		return null;
	} };
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-strategies@7.4.1/node_modules/workbox-strategies/NetworkFirst.js
	/**
	* An implementation of a
	* [network first](https://developer.chrome.com/docs/workbox/caching-strategies-overview/#network-first-falling-back-to-cache)
	* request strategy.
	*
	* By default, this strategy will cache responses with a 200 status code as
	* well as [opaque responses](https://developer.chrome.com/docs/workbox/caching-resources-during-runtime/#opaque-responses).
	* Opaque responses are are cross-origin requests where the response doesn't
	* support [CORS](https://enable-cors.org/).
	*
	* If the network request fails, and there is no cache match, this will throw
	* a `WorkboxError` exception.
	*
	* @extends workbox-strategies.Strategy
	* @memberof workbox-strategies
	*/
	var NetworkFirst = class extends Strategy {
		/**
		* @param {Object} [options]
		* @param {string} [options.cacheName] Cache name to store and retrieve
		* requests. Defaults to cache names provided by
		* {@link workbox-core.cacheNames}.
		* @param {Array<Object>} [options.plugins] [Plugins]{@link https://developers.google.com/web/tools/workbox/guides/using-plugins}
		* to use in conjunction with this caching strategy.
		* @param {Object} [options.fetchOptions] Values passed along to the
		* [`init`](https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters)
		* of [non-navigation](https://github.com/GoogleChrome/workbox/issues/1796)
		* `fetch()` requests made by this strategy.
		* @param {Object} [options.matchOptions] [`CacheQueryOptions`](https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions)
		* @param {number} [options.networkTimeoutSeconds] If set, any network requests
		* that fail to respond within the timeout will fallback to the cache.
		*
		* This option can be used to combat
		* "[lie-fi]{@link https://developers.google.com/web/fundamentals/performance/poor-connectivity/#lie-fi}"
		* scenarios.
		*/
		constructor(options = {}) {
			super(options);
			if (!this.plugins.some((p) => "cacheWillUpdate" in p)) this.plugins.unshift(cacheOkAndOpaquePlugin);
			this._networkTimeoutSeconds = options.networkTimeoutSeconds || 0;
		}
		/**
		* @private
		* @param {Request|string} request A request to run this strategy for.
		* @param {workbox-strategies.StrategyHandler} handler The event that
		*     triggered the request.
		* @return {Promise<Response>}
		*/
		async _handle(request, handler) {
			const logs = [];
			const promises = [];
			let timeoutId;
			if (this._networkTimeoutSeconds) {
				const { id, promise } = this._getTimeoutPromise({
					request,
					logs,
					handler
				});
				timeoutId = id;
				promises.push(promise);
			}
			const networkPromise = this._getNetworkPromise({
				timeoutId,
				request,
				logs,
				handler
			});
			promises.push(networkPromise);
			const response = await handler.waitUntil((async () => {
				return await handler.waitUntil(Promise.race(promises)) || await networkPromise;
			})());
			if (!response) throw new WorkboxError("no-response", { url: request.url });
			return response;
		}
		/**
		* @param {Object} options
		* @param {Request} options.request
		* @param {Array} options.logs A reference to the logs array
		* @param {Event} options.event
		* @return {Promise<Response>}
		*
		* @private
		*/
		_getTimeoutPromise({ request, logs, handler }) {
			let timeoutId;
			return {
				promise: new Promise((resolve) => {
					const onNetworkTimeout = async () => {
						resolve(await handler.cacheMatch(request));
					};
					timeoutId = setTimeout(onNetworkTimeout, this._networkTimeoutSeconds * 1e3);
				}),
				id: timeoutId
			};
		}
		/**
		* @param {Object} options
		* @param {number|undefined} options.timeoutId
		* @param {Request} options.request
		* @param {Array} options.logs A reference to the logs Array.
		* @param {Event} options.event
		* @return {Promise<Response>}
		*
		* @private
		*/
		async _getNetworkPromise({ timeoutId, request, logs, handler }) {
			let error;
			let response;
			try {
				response = await handler.fetchAndCachePut(request);
			} catch (fetchError) {
				if (fetchError instanceof Error) error = fetchError;
			}
			if (timeoutId) clearTimeout(timeoutId);
			if (error || !response) response = await handler.cacheMatch(request);
			return response;
		}
	};
	//#endregion
	//#region ../../node_modules/.pnpm/workbox-strategies@7.4.1/node_modules/workbox-strategies/StaleWhileRevalidate.js
	/**
	* An implementation of a
	* [stale-while-revalidate](https://developer.chrome.com/docs/workbox/caching-strategies-overview/#stale-while-revalidate)
	* request strategy.
	*
	* Resources are requested from both the cache and the network in parallel.
	* The strategy will respond with the cached version if available, otherwise
	* wait for the network response. The cache is updated with the network response
	* with each successful request.
	*
	* By default, this strategy will cache responses with a 200 status code as
	* well as [opaque responses](https://developer.chrome.com/docs/workbox/caching-resources-during-runtime/#opaque-responses).
	* Opaque responses are cross-origin requests where the response doesn't
	* support [CORS](https://enable-cors.org/).
	*
	* If the network request fails, and there is no cache match, this will throw
	* a `WorkboxError` exception.
	*
	* @extends workbox-strategies.Strategy
	* @memberof workbox-strategies
	*/
	var StaleWhileRevalidate = class extends Strategy {
		/**
		* @param {Object} [options]
		* @param {string} [options.cacheName] Cache name to store and retrieve
		* requests. Defaults to cache names provided by
		* {@link workbox-core.cacheNames}.
		* @param {Array<Object>} [options.plugins] [Plugins]{@link https://developers.google.com/web/tools/workbox/guides/using-plugins}
		* to use in conjunction with this caching strategy.
		* @param {Object} [options.fetchOptions] Values passed along to the
		* [`init`](https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/fetch#Parameters)
		* of [non-navigation](https://github.com/GoogleChrome/workbox/issues/1796)
		* `fetch()` requests made by this strategy.
		* @param {Object} [options.matchOptions] [`CacheQueryOptions`](https://w3c.github.io/ServiceWorker/#dictdef-cachequeryoptions)
		*/
		constructor(options = {}) {
			super(options);
			if (!this.plugins.some((p) => "cacheWillUpdate" in p)) this.plugins.unshift(cacheOkAndOpaquePlugin);
		}
		/**
		* @private
		* @param {Request|string} request A request to run this strategy for.
		* @param {workbox-strategies.StrategyHandler} handler The event that
		*     triggered the request.
		* @return {Promise<Response>}
		*/
		async _handle(request, handler) {
			const fetchAndCachePromise = handler.fetchAndCachePut(request).catch(() => {});
			handler.waitUntil(fetchAndCachePromise);
			let response = await handler.cacheMatch(request);
			let error;
			if (response) {} else try {
				response = await fetchAndCachePromise;
			} catch (err) {
				if (err instanceof Error) error = err;
			}
			if (!response) throw new WorkboxError("no-response", {
				url: request.url,
				error
			});
			return response;
		}
	};
	//#endregion
	//#region ../engine-workbox/dist/worker/runtime.js
	/** Internal header on the cached copy only; stripped before the response reaches the page. Never a public API. */
	var STAMP_HEADER = "x-pwa-platform-cached-at";
	/**
	* Registers a worker-wide quota cleanup, run whenever *any* runtime-cache write hits `QuotaExceededError` for the
	* lifetime of this worker (spec.public-read-cache "响应准入", ADR-0035 探路 2). Workbox's `registerQuotaErrorCallback`
	* is a single global registry (`workbox-core`'s `quotaErrorCallbacks`), not scoped to any one cache or plugin
	* instance, so this is the same mechanism `ExpirationPlugin({ purgeOnQuotaError: true })` uses internally — but
	* registering it here, once, independently of `createRuntimeCacheEngine`, means it fires even for a runtime cache
	* whose engine was never built (and therefore never constructed its own `ExpirationPlugin`) in this worker's
	* lifetime. Exists so `sw-runtime`, which never imports Workbox, can still guarantee "quota error clears every
	* runtime cache" without depending on which of its lazily-built engines happened to run first.
	*/
	function registerRuntimeCacheQuotaCleanup(onQuotaExceeded) {
		registerQuotaErrorCallback(onQuotaExceeded);
	}
	/** Clones `response`'s status, statusText and body with `headers` in place of its own. */
	function withHeaders(response, headers) {
		return new Response(response.body, {
			status: response.status,
			statusText: response.statusText,
			headers
		});
	}
	/**
	* Creates the runtime-cache port for one plan entry. Write-time admission and the read-time expiry stamp are the
	* platform's own; `ExpirationPlugin` only enforces `maxEntries` (LRU) and `purgeOnQuotaError`, never `maxAgeSeconds`
	* (see below).
	*/
	function createRuntimeCacheEngine(options) {
		const { cacheName, strategy, maxEntries, maxAgeSeconds, admit, networkTimeoutSeconds } = options;
		const hits = /* @__PURE__ */ new WeakMap();
		const networkFailed = /* @__PURE__ */ new WeakMap();
		const plugins = [{
			...strategy === "network-first" && networkTimeoutSeconds !== void 0 ? { async fetchDidFail({ event }) {
				if (event instanceof FetchEvent) networkFailed.set(event, true);
			} } : {},
			async cacheWillUpdate({ response }) {
				if (!await admit(response)) return null;
				const headers = new Headers(response.headers);
				headers.set(STAMP_HEADER, String(Date.now()));
				return withHeaders(response, headers);
			},
			async cachedResponseWillBeUsed({ request, cachedResponse, event }) {
				if (cachedResponse === void 0) return cachedResponse;
				const stampValue = cachedResponse.headers.get(STAMP_HEADER);
				const stamp = stampValue === null ? NaN : Number(stampValue);
				if (!Number.isFinite(stamp) || Date.now() - stamp > maxAgeSeconds * 1e3) {
					await (await self.caches.open(cacheName)).delete(request);
					return;
				}
				if (event instanceof FetchEvent) {
					const reason = strategy !== "network-first" ? "stale-while-revalidate" : networkFailed.get(event) === true ? "network-failed" : networkTimeoutSeconds !== void 0 ? "network-timeout" : "network-failed";
					hits.set(event, {
						cachedAt: stamp,
						reason
					});
				}
				const headers = new Headers(cachedResponse.headers);
				headers.delete(STAMP_HEADER);
				return withHeaders(cachedResponse, headers);
			}
		}, new ExpirationPlugin({
			maxEntries,
			purgeOnQuotaError: true
		})];
		const strategyInstance = strategy === "network-first" ? new NetworkFirst(networkTimeoutSeconds === void 0 ? {
			cacheName,
			plugins
		} : {
			cacheName,
			plugins,
			networkTimeoutSeconds
		}) : new StaleWhileRevalidate({
			cacheName,
			plugins
		});
		return { async handle(event) {
			const [responseDone, handlerDone] = strategyInstance.handleAll({
				event,
				request: event.request
			});
			event.waitUntil(handlerDone.catch(() => void 0));
			const response = await responseDone;
			const servedFromCache = hits.get(event) ?? null;
			hits.delete(event);
			networkFailed.delete(event);
			return {
				response,
				servedFromCache
			};
		} };
	}
	//#endregion
	//#region ../sw-runtime/dist/shared/config.js
	/** contracts' `REQUEST_BASELINE_DENIALS`, in the same canonical order (a unit test keeps them equal). */
	var WORKER_BASELINE_DENIALS = [
		"non-get",
		"cross-origin",
		"no-store",
		"opaque-response",
		"redirect",
		"websocket",
		"unclassified"
	];
	/**
	* `"exclude"` and `"deny"` followed by contracts' `CACHE_STRATEGIES` (a unit test keeps them equal). `"exclude"` only
	* appears in a shared-origin root app's plan, once per child scope (ADR-0019).
	*/
	var WORKER_PATH_RULE_ACTIONS = [
		"exclude",
		"deny",
		"none",
		"cache-first",
		"network-first",
		"stale-while-revalidate"
	];
	var PRECACHE_CACHE_NAME = /^pwa:[^:]+:[^:]+:[^:]+:precache$/;
	var OFFLINE_WRITE_DATABASE_NAME = /^pwa-offline-write:[^:]+:[^:]+:[^:]+$/;
	var OFFLINE_WRITE_ID = /^[a-z][a-z0-9-]{0,63}$/;
	var RUNTIME_PAGES_CACHE_NAME = /^pwa:[^:]+:[^:]+:[^:]+:runtime-pages$/;
	var RUNTIME_DATA_CACHE_NAME_PREFIX = /^pwa:[^:]+:[^:]+:[^:]+:runtime-data-$/;
	var RUNTIME_DATA_CACHE_NAME = /^pwa:[^:]+:[^:]+:[^:]+:runtime-data-[0-9a-f]{16}$/;
	var RUNTIME_RESOURCE_CLASSES = ["public-data", "navigation-public-dynamic"];
	var RUNTIME_STRATEGIES = ["network-first", "stale-while-revalidate"];
	var PATH_BASE = "https://sw-runtime.invalid";
	var PLATFORM_KEYS = [
		"kind",
		"version",
		"scope",
		"precacheCacheName",
		"requestBaselineDenials",
		"pathRules",
		"offlineFallback",
		"updateMode",
		"offlineWrites",
		"runtimeCache"
	];
	/** Validates a platform worker config and returns a fresh copy with keys in canonical order. Messages name fields only. */
	function validatePlatformWorkerConfig(value) {
		const config = plainObject(value, "config");
		const hasNetworkTimeout = Object.hasOwn(config, "networkTimeoutSeconds");
		exactKeys(config, hasNetworkTimeout ? [...PLATFORM_KEYS, "networkTimeoutSeconds"] : PLATFORM_KEYS, "config");
		if (config["kind"] !== "platform") fail("config.kind must be \"platform\"");
		if (config["version"] !== 1) fail("config.version must be 1");
		const scope = canonicalPath(config["scope"], "config.scope");
		if (!scope.endsWith("/")) fail("config.scope must end with \"/\"");
		const precacheCacheName = config["precacheCacheName"];
		if (typeof precacheCacheName !== "string" || !PRECACHE_CACHE_NAME.test(precacheCacheName)) fail("config.precacheCacheName must have the form \"pwa:<app>:<environment>:<seed>:precache\"");
		const denials = config["requestBaselineDenials"];
		if (!(Array.isArray(denials) && denials.length === WORKER_BASELINE_DENIALS.length && WORKER_BASELINE_DENIALS.every((denial, index) => denials[index] === denial))) fail("config.requestBaselineDenials must list every baseline denial once, in canonical order");
		const rules = config["pathRules"];
		if (!Array.isArray(rules)) fail("config.pathRules must be an array");
		const pathRules = rules.map((entry, index) => {
			const label = `config.pathRules[${index}]`;
			const rule = plainObject(entry, label);
			exactKeys(rule, ["pathPrefix", "action"], label);
			const pathPrefix = canonicalPath(rule["pathPrefix"], `${label}.pathPrefix`);
			const action = rule["action"];
			if (!WORKER_PATH_RULE_ACTIONS.some((known) => known === action)) fail(`${label}.action must be "exclude", "deny" or a cache strategy`);
			return {
				pathPrefix,
				action
			};
		});
		const fallback = plainObject(config["offlineFallback"], "config.offlineFallback");
		let offlineFallback;
		if (fallback["enabled"] === false) {
			exactKeys(fallback, ["enabled"], "config.offlineFallback");
			offlineFallback = { enabled: false };
		} else if (fallback["enabled"] === true) {
			exactKeys(fallback, ["enabled", "path"], "config.offlineFallback");
			offlineFallback = {
				enabled: true,
				path: canonicalPath(fallback["path"], "config.offlineFallback.path")
			};
		} else fail("config.offlineFallback.enabled must be true or false");
		if (config["updateMode"] !== "prompt") fail("config.updateMode must be \"prompt\"");
		const offlineWrites = offlineWriteConfig(config["offlineWrites"], scope);
		const runtimeCache = runtimeCacheConfig(config["runtimeCache"]);
		const networkTimeoutSeconds = hasNetworkTimeout ? boundedInteger(config["networkTimeoutSeconds"], 1, 30, "config.networkTimeoutSeconds") : void 0;
		return {
			kind: "platform",
			version: 1,
			scope,
			precacheCacheName,
			requestBaselineDenials: [...WORKER_BASELINE_DENIALS],
			pathRules,
			offlineFallback,
			updateMode: "prompt",
			offlineWrites,
			runtimeCache,
			...networkTimeoutSeconds === void 0 ? {} : { networkTimeoutSeconds }
		};
	}
	function fail(detail) {
		throw new Error(`Invalid sw-runtime worker config: ${detail}`);
	}
	function plainObject(value, label) {
		const prototype = typeof value === "object" && value !== null ? Object.getPrototypeOf(value) : void 0;
		if (Array.isArray(value) || prototype !== Object.prototype && prototype !== null) fail(`${label} must be a plain object`);
		return value;
	}
	function exactKeys(record, keys, label) {
		if (Reflect.ownKeys(record).length !== keys.length || !keys.every((key) => Object.hasOwn(record, key))) fail(`${label} must have exactly the fields ${keys.join(", ")}`);
	}
	function offlineWriteConfig(value, scope) {
		const config = plainObject(value, "config.offlineWrites");
		if (config["enabled"] === false) {
			exactKeys(config, ["enabled"], "config.offlineWrites");
			return { enabled: false };
		}
		if (config["enabled"] !== true) fail("config.offlineWrites.enabled must be true or false");
		exactKeys(config, [
			"enabled",
			"databaseName",
			"maxEntries",
			"maxTotalBodyBytes",
			"targets"
		], "config.offlineWrites");
		const databaseName = config["databaseName"];
		if (typeof databaseName !== "string" || !OFFLINE_WRITE_DATABASE_NAME.test(databaseName)) fail("config.offlineWrites.databaseName must have the form \"pwa-offline-write:<app>:<environment>:<seed>\"");
		const maxEntries = boundedPositiveInteger(config["maxEntries"], 50, "config.offlineWrites.maxEntries");
		const maxTotalBodyBytes = boundedPositiveInteger(config["maxTotalBodyBytes"], 524288, "config.offlineWrites.maxTotalBodyBytes");
		const rawTargets = config["targets"];
		if (!Array.isArray(rawTargets) || rawTargets.length === 0) fail("config.offlineWrites.targets must be a non-empty array");
		const targetIds = /* @__PURE__ */ new Set();
		const targetPaths = /* @__PURE__ */ new Set();
		return {
			enabled: true,
			databaseName,
			maxEntries,
			maxTotalBodyBytes,
			targets: rawTargets.map((entry, index) => {
				const label = `config.offlineWrites.targets[${index}]`;
				const target = plainObject(entry, label);
				exactKeys(target, [
					"id",
					"pathPrefix",
					"maxBodyBytes"
				], label);
				const id = target["id"];
				if (typeof id !== "string" || !OFFLINE_WRITE_ID.test(id)) fail(`${label}.id must be an ASCII slug`);
				const pathPrefix = canonicalPath(target["pathPrefix"], `${label}.pathPrefix`);
				if (!isWithinScope(pathPrefix, scope)) fail(`${label}.pathPrefix must be inside config.scope`);
				const maxBodyBytes = boundedPositiveInteger(target["maxBodyBytes"], 16384, `${label}.maxBodyBytes`);
				if (targetIds.has(id)) fail(`${label}.id must be unique`);
				const pathKey = decodedPathKey$1(pathPrefix, `${label}.pathPrefix`);
				if (targetPaths.has(pathKey)) fail(`${label}.pathPrefix must be unique after URL decoding`);
				targetIds.add(id);
				targetPaths.add(pathKey);
				return {
					id,
					pathPrefix,
					maxBodyBytes
				};
			})
		};
	}
	function runtimeCacheConfig(value) {
		const config = plainObject(value, "config.runtimeCache");
		if (config["enabled"] === false) {
			exactKeys(config, [
				"enabled",
				"pagesCacheName",
				"dataCacheNamePrefix"
			], "config.runtimeCache");
			return {
				enabled: false,
				pagesCacheName: runtimeCacheNameField(config["pagesCacheName"], RUNTIME_PAGES_CACHE_NAME, "config.runtimeCache.pagesCacheName"),
				dataCacheNamePrefix: runtimeCacheNameField(config["dataCacheNamePrefix"], RUNTIME_DATA_CACHE_NAME_PREFIX, "config.runtimeCache.dataCacheNamePrefix")
			};
		}
		if (config["enabled"] !== true) fail("config.runtimeCache.enabled must be true or false");
		exactKeys(config, [
			"enabled",
			"pagesCacheName",
			"dataCacheNamePrefix",
			"dataCacheName",
			"maxEntries",
			"maxEntryBytes",
			"maxAgeSeconds",
			"rules"
		], "config.runtimeCache");
		const pagesCacheName = runtimeCacheNameField(config["pagesCacheName"], RUNTIME_PAGES_CACHE_NAME, "config.runtimeCache.pagesCacheName");
		const dataCacheNamePrefix = runtimeCacheNameField(config["dataCacheNamePrefix"], RUNTIME_DATA_CACHE_NAME_PREFIX, "config.runtimeCache.dataCacheNamePrefix");
		const dataCacheName = config["dataCacheName"];
		if (typeof dataCacheName !== "string" || !RUNTIME_DATA_CACHE_NAME.test(dataCacheName) || !dataCacheName.startsWith(dataCacheNamePrefix)) fail("config.runtimeCache.dataCacheName must have the form \"pwa:<app>:<environment>:<seed>:runtime-data-<digest>\"");
		const maxEntries = boundedInteger(config["maxEntries"], 1, 200, "config.runtimeCache.maxEntries");
		const maxEntryBytes = boundedInteger(config["maxEntryBytes"], 1, 1048576, "config.runtimeCache.maxEntryBytes");
		const maxAgeSeconds = boundedInteger(config["maxAgeSeconds"], 60, 604800, "config.runtimeCache.maxAgeSeconds");
		const rawRules = config["rules"];
		if (!Array.isArray(rawRules)) fail("config.runtimeCache.rules must be an array");
		return {
			enabled: true,
			pagesCacheName,
			dataCacheNamePrefix,
			dataCacheName,
			maxEntries,
			maxEntryBytes,
			maxAgeSeconds,
			rules: rawRules.map((entry, index) => {
				const label = `config.runtimeCache.rules[${index}]`;
				const rule = plainObject(entry, label);
				exactKeys(rule, [
					"pathPrefix",
					"resourceClass",
					"strategy"
				], label);
				const pathPrefix = canonicalPath(rule["pathPrefix"], `${label}.pathPrefix`);
				const resourceClass = rule["resourceClass"];
				if (!RUNTIME_RESOURCE_CLASSES.some((known) => known === resourceClass)) fail(`${label}.resourceClass must be "public-data" or "navigation-public-dynamic"`);
				const strategy = rule["strategy"];
				if (!RUNTIME_STRATEGIES.some((known) => known === strategy)) fail(`${label}.strategy must be "network-first" or "stale-while-revalidate"`);
				return {
					pathPrefix,
					resourceClass,
					strategy
				};
			})
		};
	}
	function runtimeCacheNameField(value, pattern, label) {
		if (typeof value !== "string" || !pattern.test(value)) fail(`${label} must have the form "pwa:<app>:<environment>:<seed>:runtime-…"`);
		return value;
	}
	function boundedInteger(value, minimum, maximum, label) {
		if (typeof value !== "number" || !Number.isInteger(value) || value < minimum || value > maximum) fail(`${label} must be an integer between ${minimum} and ${maximum}`);
		return value;
	}
	function boundedPositiveInteger(value, maximum, label) {
		if (typeof value !== "number" || !Number.isInteger(value) || value < 1 || value > maximum) fail(`${label} must be an integer between 1 and ${maximum}`);
		return value;
	}
	function isWithinScope(path, scope) {
		return scope === "/" || path === scope.slice(0, -1) || path.startsWith(scope);
	}
	function decodedPathKey$1(path, label) {
		try {
			return path.split("/").map(decodeURIComponent).join("/");
		} catch {
			fail(`${label} must contain valid percent escapes`);
		}
	}
	/**
	* The rule contracts' `isCanonicalPath` applies to plan paths: an absolute path already in WHATWG URL serialized form,
	* without "//", backslashes, query, fragment or characters the URL parser would change.
	*/
	function canonicalPath(value, label) {
		if (!(typeof value === "string" && value.startsWith("/") && !value.includes("//") && !value.includes("\\") && URL.canParse(value, PATH_BASE) && new URL(value, PATH_BASE).pathname === value)) fail(`${label} must be a canonical absolute path`);
		return value;
	}
	//#endregion
	//#region ../sw-runtime/dist/messages/index.js
	var SKIP_WAITING_MESSAGE = Object.freeze({ type: "pwa:skip-waiting" });
	/**
	* True only for a plain object (this realm's `Object.prototype` or a null prototype) whose single own property is a
	* `type` data property equal to `"pwa:skip-waiting"`. Structured-cloned messages have that shape; accessors are
	* never invoked.
	*/
	function isSkipWaitingMessage(value) {
		if (typeof value !== "object" || value === null) return false;
		const prototype = Object.getPrototypeOf(value);
		if (prototype !== Object.prototype && prototype !== null) return false;
		const keys = Reflect.ownKeys(value);
		if (keys.length !== 1 || keys[0] !== "type") return false;
		const descriptor = Object.getOwnPropertyDescriptor(value, "type");
		return descriptor !== void 0 && "value" in descriptor && descriptor.value === SKIP_WAITING_MESSAGE.type;
	}
	/**
	* Recognizes only the v1 offline-write request envelopes. It deliberately validates only wire shape: target matching,
	* JSON encoding, length limits and persistence are enforced together by the queue so a future caller cannot mistake
	* a syntactically valid message for an accepted write. Reads never invoke a page-provided accessor.
	*/
	function isOfflineWriteMessage(value) {
		try {
			const envelope = plainDataObject(value);
			if (envelope === void 0 || read(envelope, "version") !== 1 || typeof read(envelope, "requestId") !== "string") return false;
			const type = read(envelope, "type");
			if (type === "pwa:offline-write:clear") return dataObject(value, [
				"type",
				"version",
				"requestId"
			]) !== void 0;
			if (type === "pwa:offline-write:flush") {
				const flush = dataObject(value, [
					"type",
					"version",
					"requestId",
					"sessionBinding"
				]);
				return flush !== void 0 && typeof read(flush, "sessionBinding") === "string";
			}
			if (type !== "pwa:offline-write:enqueue") return false;
			const enqueue = dataObject(value, [
				"type",
				"version",
				"requestId",
				"intent"
			]);
			if (enqueue === void 0) return false;
			const intent = dataObject(read(enqueue, "intent"), [
				"targetId",
				"path",
				"body",
				"idempotencyKey",
				"sessionBinding"
			]);
			return intent !== void 0 && typeof read(intent, "targetId") === "string" && typeof read(intent, "path") === "string" && typeof read(intent, "idempotencyKey") === "string" && typeof read(intent, "sessionBinding") === "string";
		} catch {
			return false;
		}
	}
	/** Matches only the closed `{ type, version }` request envelope. Reads never invoke a page-provided accessor. */
	function isRuntimeCachePendingMessage(value) {
		const message = dataObject(value, ["type", "version"]);
		return message !== void 0 && read(message, "type") === "pwa:runtime-cache:pending" && read(message, "version") === 1;
	}
	function dataObject(value, keys) {
		const record = plainDataObject(value);
		if (record === void 0) return void 0;
		const actual = Reflect.ownKeys(record);
		if (actual.length !== keys.length || !keys.every((key) => actual.includes(key))) return void 0;
		return record;
	}
	function plainDataObject(value) {
		if (typeof value !== "object" || value === null || Array.isArray(value)) return void 0;
		const prototype = Object.getPrototypeOf(value);
		if (prototype !== Object.prototype && prototype !== null) return void 0;
		if (Reflect.ownKeys(value).some((key) => typeof key !== "string" || !hasDataProperty(value, key))) return void 0;
		return value;
	}
	function hasDataProperty(value, key) {
		const descriptor = Object.getOwnPropertyDescriptor(value, key);
		return descriptor !== void 0 && "value" in descriptor;
	}
	function read(value, key) {
		const descriptor = Object.getOwnPropertyDescriptor(value, key);
		return descriptor !== void 0 && "value" in descriptor ? descriptor.value : void 0;
	}
	var FIELD_ORDER = [
		"title",
		"body",
		"tag",
		"url",
		"data"
	];
	var FIELD_LIMITS = {
		title: {
			required: true,
			min: 1,
			max: 120
		},
		body: {
			required: false,
			min: 0,
			max: 480
		},
		tag: {
			required: false,
			min: 1,
			max: 64
		},
		url: {
			required: false,
			min: 1,
			max: 2048
		},
		data: {
			required: false,
			min: 0,
			max: 256
		}
	};
	var KNOWN_KEYS = /* @__PURE__ */ new Set([
		"v",
		"title",
		"body",
		"tag",
		"url",
		"data"
	]);
	/** True only for a data property descriptor: an accessor is never invoked to read its value. */
	function isDataDescriptor(descriptor) {
		return "value" in descriptor;
	}
	/** Unicode code point count, so an astral character (e.g. an emoji) counts once rather than as two UTF-16 units. */
	function codePointLength(text) {
		return [...text].length;
	}
	/**
	* Validates an already-parsed value against the payload format. Reports every issue found, in a deterministic
	* order: unknown fields (in the order their keys appear on the object), then the version, then each known field in
	* schema order. Never invokes an accessor property and never includes an input value in an issue. Used directly by
	* the server-side payload builder (a later task); the worker and `checkPushPayloadText` go through this too.
	*/
	function checkPushPayload(value) {
		if (typeof value !== "object" || value === null || Array.isArray(value)) return {
			ok: false,
			issues: [{
				code: "push.payload-not-object",
				path: ""
			}]
		};
		const prototype = Object.getPrototypeOf(value);
		if (prototype !== Object.prototype && prototype !== null) return {
			ok: false,
			issues: [{
				code: "push.payload-not-object",
				path: ""
			}]
		};
		const issues = [];
		for (const key of Reflect.ownKeys(value)) if (!KNOWN_KEYS.has(key)) issues.push({
			code: "push.payload-unknown-field",
			path: ""
		});
		const versionDescriptor = Object.getOwnPropertyDescriptor(value, "v");
		if (versionDescriptor === void 0 || !isDataDescriptor(versionDescriptor) || versionDescriptor.value !== 1) issues.push({
			code: "push.payload-version",
			path: "/v"
		});
		const fields = {};
		for (const field of FIELD_ORDER) {
			const limit = FIELD_LIMITS[field];
			const descriptor = Object.getOwnPropertyDescriptor(value, field);
			if (descriptor === void 0) {
				if (limit.required) issues.push({
					code: "push.payload-field-type",
					path: `/${field}`
				});
				continue;
			}
			if (!isDataDescriptor(descriptor) || typeof descriptor.value !== "string") {
				issues.push({
					code: "push.payload-field-type",
					path: `/${field}`
				});
				continue;
			}
			const fieldValue = descriptor.value;
			const length = codePointLength(fieldValue);
			if (length < limit.min || length > limit.max) {
				issues.push({
					code: "push.payload-field-length",
					path: `/${field}`
				});
				continue;
			}
			fields[field] = fieldValue;
		}
		if (issues.length > 0) return {
			ok: false,
			issues
		};
		const payload = { title: fields.title };
		if (fields.body !== void 0) payload.body = fields.body;
		if (fields.tag !== void 0) payload.tag = fields.tag;
		if (fields.url !== void 0) payload.url = fields.url;
		if (fields.data !== void 0) payload.data = fields.data;
		return {
			ok: true,
			value: Object.freeze({
				v: 1,
				...payload
			})
		};
	}
	/**
	* Validates the raw push text as received by the worker: the UTF-8 byte limit on the text itself, then `JSON.parse`,
	* then `checkPushPayload`. Never throws: a `JSON.parse` failure becomes a `push.payload-not-json` issue.
	*/
	function checkPushPayloadText(text) {
		if (new TextEncoder().encode(text).length > 3072) return {
			ok: false,
			issues: [{
				code: "push.payload-too-large",
				path: ""
			}]
		};
		let parsed;
		try {
			parsed = JSON.parse(text);
		} catch {
			return {
				ok: false,
				issues: [{
					code: "push.payload-not-json",
					path: ""
				}]
			};
		}
		return checkPushPayload(parsed);
	}
	/** Convenience for the worker: the payload, or `null` for anything invalid. */
	function validatePushPayload(text) {
		const result = checkPushPayloadText(text);
		return result.ok ? result.value : null;
	}
	//#endregion
	//#region ../sw-runtime/dist/worker/admit.js
	var ALLOWED_VARY_TOKENS = /* @__PURE__ */ new Set(["accept", "accept-encoding"]);
	/** The first admission condition `response` fails, or undefined when it may be written. Never consumes `response`. */
	async function runtimeAdmissionRejection(response, options) {
		if (response.type !== "basic") return "response-type";
		if (response.status !== 200) return "status";
		if (response.redirected) return "redirected";
		if (!admittedMediaType(response.headers.get("content-type"), options.resourceClass)) return "content-type";
		if (!admittedCacheControl(response.headers.get("cache-control"), options.strategy)) return "cache-control";
		if (!admittedVary(response.headers.get("vary"))) return "vary";
		return await admittedSize(response, options.maxEntryBytes) ? void 0 : "size";
	}
	function admittedMediaType(contentType, resourceClass) {
		if (contentType === null) return false;
		const mediaType = contentType.split(";", 1)[0].trim().toLowerCase();
		if (resourceClass === "navigation-public-dynamic") return mediaType === "text/html";
		return mediaType === "application/json" || /^application\/[^/]+\+json$/.test(mediaType);
	}
	/** Each directive token, with its value when the token carries one (`max-age=0` and `max-age="0"` both parse to `0`). */
	function directives(headerValue) {
		const found = /* @__PURE__ */ new Map();
		for (const item of headerValue.split(",")) {
			const [rawToken, ...rawValue] = item.split("=");
			const token = rawToken?.trim().toLowerCase();
			if (token === void 0 || token.length === 0) continue;
			const value = rawValue.length === 0 ? void 0 : rawValue.join("=").trim().replace(/^"|"$/g, "");
			found.set(token, value);
		}
		return found;
	}
	/** True when `directive` is present with a numeric value of exactly `0` (e.g. `max-age=0`, `max-age="0"`). */
	function isZero(found, directive) {
		const value = found.get(directive);
		return value !== void 0 && Number(value) === 0;
	}
	function admittedCacheControl(cacheControl, strategy) {
		if (cacheControl === null) return true;
		const found = directives(cacheControl);
		if (found.has("no-store") || found.has("private")) return false;
		if (strategy === "stale-while-revalidate") {
			if (found.has("no-cache") || found.has("must-revalidate")) return false;
			if (isZero(found, "max-age") || isZero(found, "s-maxage")) return false;
		}
		return true;
	}
	function admittedVary(vary) {
		if (vary === null) return true;
		return vary.split(",").map((token) => token.trim().toLowerCase()).filter((token) => token.length > 0).every((token) => ALLOWED_VARY_TOKENS.has(token));
	}
	async function admittedSize(response, maxEntryBytes) {
		const contentLength = response.headers.get("content-length");
		if (contentLength !== null) {
			const declared = Number(contentLength);
			if (Number.isInteger(declared) && declared >= 0 && declared > maxEntryBytes) return false;
		}
		const body = response.clone().body;
		if (body === null) return true;
		const reader = body.getReader();
		let total = 0;
		for (;;) {
			const { done, value } = await reader.read();
			if (done) {
				reader.releaseLock();
				return true;
			}
			total += value.length;
			if (total > maxEntryBytes) {
				reader.cancel().catch(() => {});
				return false;
			}
		}
	}
	//#endregion
	//#region ../sw-runtime/dist/shared/path-match.js
	var ENCODED_SLASH = "\ud800";
	var UTF8_DECODER = new TextDecoder("utf-8", { ignoreBOM: true });
	var UTF8_ENCODER = new TextEncoder();
	/**
	* Comparison key for a path, decoded per segment like the URL standard: valid `%XX` escapes become bytes, invalid
	* escapes stay literal, and bytes that are not UTF-8 become U+FFFD. Distinct spellings can only collapse into one
	* key, never split.
	*/
	function decodedPathKey(path) {
		return path.split("/").map((segment) => segment.split(/%2f/i).map(percentDecode).join(ENCODED_SLASH)).join("/");
	}
	/** Whole-segment containment of decoded keys: `/app/api/x` is within `/app/api`, `/app/apis` is not. */
	function isWithinPrefix(pathKey, prefixKey) {
		return prefixKey === "/" || pathKey === prefixKey || pathKey.startsWith(`${prefixKey}/`);
	}
	/**
	* Matcher over the plan's path rules, whose order is the evaluation order. Prefix keys are decoded once, so each
	* request only decodes its own path. The query and fragment are ignored.
	*/
	function createPathMatcher(rules) {
		const prefixKeys = rules.map((rule) => decodedPathKey(rule.pathPrefix));
		return { match(path) {
			const pathKey = decodedPathKey(pathOnly(path));
			const index = prefixKeys.findIndex((prefixKey) => isWithinPrefix(pathKey, prefixKey));
			return index === -1 ? void 0 : rules[index];
		} };
	}
	function pathOnly(path) {
		const end = path.search(/[?#]/);
		return end === -1 ? path : path.slice(0, end);
	}
	function percentDecode(text) {
		const bytes = [];
		for (let index = 0; index < text.length; index += 1) {
			const escape = text.slice(index + 1, index + 3);
			if (text[index] === "%" && /^[0-9A-Fa-f]{2}$/.test(escape)) {
				bytes.push(Number.parseInt(escape, 16));
				index += 2;
				continue;
			}
			const character = String.fromCodePoint(text.codePointAt(index) ?? 0);
			bytes.push(...UTF8_ENCODER.encode(character));
			index += character.length - 1;
		}
		return UTF8_DECODER.decode(Uint8Array.from(bytes));
	}
	//#endregion
	//#region ../sw-runtime/dist/worker/decide.js
	var PASSTHROUGH = (reason) => ({
		kind: "passthrough",
		reason
	});
	function createRouter({ config, manifestUrls, origin }) {
		const matcher = createPathMatcher(config.pathRules);
		const manifest = new Set(manifestUrls);
		const runtimeRules = new Map(config.runtimeCache.enabled ? config.runtimeCache.rules.map((rule) => [rule.pathPrefix, rule]) : []);
		return { decide({ method, url, navigation, range, authorization }) {
			if (method !== "GET") return PASSTHROUGH("non-get");
			if (!URL.canParse(url)) return PASSTHROUGH("unparsable");
			const requested = new URL(url);
			if (requested.origin !== origin) return PASSTHROUGH("cross-origin");
			const rule = matcher.match(requested.pathname);
			if (rule === void 0) return PASSTHROUGH("unclassified");
			if (rule.action === "exclude") return PASSTHROUGH("excluded");
			if (rule.action === "deny") {
				const offline = navigation ? offlineFallback(config, manifest) : void 0;
				return offline === void 0 ? PASSTHROUGH("denied") : {
					kind: "navigate",
					fallbacks: [offline]
				};
			}
			const runtimeRule = runtimeRules.get(rule.pathPrefix);
			if (navigation) {
				const fallbacks = navigationFallbacks(config, manifest, requested);
				if (runtimeRule !== void 0 && runtimeRule.resourceClass === "navigation-public-dynamic" && !authorization) return {
					kind: "runtime",
					cache: "pages",
					strategy: runtimeRule.strategy,
					resourceClass: runtimeRule.resourceClass,
					fallbacks
				};
				return {
					kind: "navigate",
					fallbacks
				};
			}
			const exact = `${requested.pathname}${requested.search}`;
			if (!manifest.has(exact)) {
				if (runtimeRule !== void 0 && runtimeRule.resourceClass === "public-data") {
					if (range) return PASSTHROUGH("range");
					if (authorization) return PASSTHROUGH("authorization");
					return {
						kind: "runtime",
						cache: "data",
						strategy: runtimeRule.strategy,
						resourceClass: runtimeRule.resourceClass,
						fallbacks: []
					};
				}
				return PASSTHROUGH("not-precached");
			}
			return range ? PASSTHROUGH("range") : {
				kind: "precache",
				manifestUrl: exact
			};
		} };
	}
	/**
	* What an offline navigation may fall back to, in order: the requested URL itself (query string intact), the same
	* route with the query string dropped, that route's `index.html` (query string dropped), and finally the plan's
	* offline fallback page. Nothing else: no other route's cached content may answer a navigation.
	*
	* The exact, query-preserving candidate is tried first so a precached query-string variant still wins when one
	* exists. Only once that misses does the query string get dropped (ADR-0034, 2026-09-23 amendment): a decorated URL
	* — for example a return-path query on an entry-recovery link — used to skip its own precached document and land on
	* the offline page solely because of its query string. Dropping the query string on the fallback candidates lets it
	* reach that document instead, while still never answering with a different route's cached content.
	*
	* The route's `index.html` is tried for URLs with and without a trailing slash. Frameworks that prerender write
	* `about/index.html` but link to `/about` (Nuxt does by default), and a static host serves both spellings from that
	* one file, so both name the same route (ADR-0012, 2026-09-17 amendment).
	*/
	function navigationFallbacks(config, manifest, requested) {
		const { pathname, search } = requested;
		const candidates = [`${pathname}${search}`, pathname];
		candidates.push(pathname.endsWith("/") ? `${pathname}index.html` : `${pathname}/index.html`);
		const offline = offlineFallback(config, manifest);
		if (offline !== void 0) candidates.push(offline);
		return [...new Set(candidates.filter((candidate) => manifest.has(candidate)))];
	}
	/** The offline page, when the plan enables one and the precache holds it. */
	function offlineFallback(config, manifest) {
		return config.offlineFallback.enabled && manifest.has(config.offlineFallback.path) ? config.offlineFallback.path : void 0;
	}
	//#endregion
	//#region ../sw-runtime/dist/worker/offline-write-intent.js
	var OPAQUE_ASCII = /^[\x21-\x7e]{1,128}$/;
	var SESSION_BINDING = /^[\x21-\x7e]{16,128}$/;
	/** Validates and canonicalizes one explicit enqueue request before any persistent storage is opened. */
	function validateOfflineWriteEnqueue(message, config, origin) {
		if (!config.offlineWrites.enabled) return {
			ok: false,
			code: "offline-write.disabled"
		};
		const { intent } = message;
		const target = config.offlineWrites.targets.find((candidate) => candidate.id === intent.targetId);
		if (target === void 0) return {
			ok: false,
			code: "offline-write.target"
		};
		if (!OPAQUE_ASCII.test(intent.idempotencyKey)) return {
			ok: false,
			code: "offline-write.idempotency-key"
		};
		if (!SESSION_BINDING.test(intent.sessionBinding)) return {
			ok: false,
			code: "offline-write.session-binding"
		};
		const path = canonicalSameOriginPath(intent.path, origin);
		if (path === void 0 || !isWithin(path, config.scope) || !isWithin(path, target.pathPrefix)) return {
			ok: false,
			code: "offline-write.path"
		};
		const bodyJson = jsonText(intent.body);
		if (bodyJson === void 0 || new TextEncoder().encode(bodyJson).length > target.maxBodyBytes) return {
			ok: false,
			code: "offline-write.body"
		};
		return {
			ok: true,
			value: {
				targetId: target.id,
				path,
				bodyJson,
				idempotencyKey: intent.idempotencyKey,
				sessionBinding: intent.sessionBinding
			}
		};
	}
	/** Checks the current page's opaque binding before a later flush may inspect stored records. */
	function validateOfflineWriteFlush(message, config) {
		if (!config.offlineWrites.enabled) return {
			ok: false,
			code: "offline-write.disabled"
		};
		if (!SESSION_BINDING.test(message.sessionBinding)) return {
			ok: false,
			code: "offline-write.session-binding"
		};
		return {
			ok: true,
			binding: message.sessionBinding
		};
	}
	function canonicalSameOriginPath(value, origin) {
		if (!value.startsWith("/") || !URL.canParse(value, origin)) return void 0;
		const url = new URL(value, origin);
		return url.origin === origin && url.search === "" && url.hash === "" && url.pathname === value ? value : void 0;
	}
	function isWithin(path, prefix) {
		if (prefix === "/") return true;
		const directory = prefix.endsWith("/") ? prefix : `${prefix}/`;
		return path === prefix || path === directory.slice(0, -1) || path.startsWith(directory);
	}
	function jsonText(value) {
		try {
			if (!isJsonValue(value, /* @__PURE__ */ new WeakSet())) return void 0;
			const text = JSON.stringify(value);
			return text === void 0 ? void 0 : text;
		} catch {
			return;
		}
	}
	function isJsonValue(value, seen) {
		if (value === null || typeof value === "string" || typeof value === "boolean") return true;
		if (typeof value === "number") return Number.isFinite(value);
		if (typeof value !== "object" || seen.has(value)) return false;
		seen.add(value);
		if (Array.isArray(value)) {
			for (let index = 0; index < value.length; index += 1) {
				const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
				if (descriptor === void 0 || !("value" in descriptor) || !isJsonValue(descriptor.value, seen)) return false;
			}
			return true;
		}
		const prototype = Object.getPrototypeOf(value);
		if (prototype !== Object.prototype && prototype !== null) return false;
		for (const key of Reflect.ownKeys(value)) {
			if (typeof key !== "string") return false;
			const descriptor = Object.getOwnPropertyDescriptor(value, key);
			if (descriptor === void 0 || !("value" in descriptor) || !isJsonValue(descriptor.value, seen)) return false;
		}
		return true;
	}
	//#endregion
	//#region ../sw-runtime/dist/worker/offline-write-flush.js
	/**
	* Explicit FIFO replay; it is never called by fetch, Sync, Push or worker activation.
	*
	* `onPrepared`, when given, runs synchronously right after `store.prepareFlush` resolves, before the send loop
	* starts — handlers.ts's single-flight bookkeeping uses it to tell a flush request that joins this round while the
	* read is still pending (still eligible to observe this round's snapshot) apart from one that arrives afterward,
	* during the send loop, which cannot: that one is coalesced into a trailing pass instead (spec "增补：flush 单飞的
	* trailing pass", N2).
	*/
	async function flushOfflineWrites(store, binding, origin, send, onPrepared) {
		const prepared = await store.prepareFlush(binding);
		onPrepared?.();
		let sent = 0;
		let retained = 0;
		let failed = 0;
		for (const write of prepared.writes) try {
			const response = await send(new URL(write.path, origin), {
				method: "POST",
				credentials: "same-origin",
				headers: {
					"content-type": "application/json",
					"idempotency-key": write.idempotencyKey
				},
				body: write.bodyJson
			});
			if (response.ok) {
				await store.remove(write.idempotencyKey);
				sent += 1;
			} else if (response.status >= 500) retained += 1;
			else {
				await store.markFailed(write.idempotencyKey, response.status === 401 || response.status === 403 ? "authorization-required" : "rejected");
				failed += 1;
			}
		} catch {
			retained += 1;
		}
		return {
			sent,
			retained,
			failed,
			purged: prepared.purged
		};
	}
	//#endregion
	//#region ../sw-runtime/dist/worker/offline-write-store.js
	var STORE_NAME = "writes";
	/**
	* The worker-owned IndexedDB queue. Every admission decision and write shares one readwrite transaction, so a
	* concurrent enqueue cannot overrun a quota or turn one idempotency key into two different stored intents.
	*/
	function createOfflineWriteStore(config) {
		return {
			async enqueue(intent) {
				const db = await openDatabase(config.databaseName);
				try {
					return await new Promise((resolve, reject) => {
						const transaction = db.transaction(STORE_NAME, "readwrite");
						let outcome;
						transaction.oncomplete = () => {
							if (outcome === void 0) reject(/* @__PURE__ */ new Error("offline-write transaction completed without an outcome"));
							else resolve(outcome);
						};
						transaction.onabort = () => reject(transaction.error ?? /* @__PURE__ */ new Error("offline-write transaction aborted"));
						transaction.onerror = () => reject(transaction.error ?? /* @__PURE__ */ new Error("offline-write transaction failed"));
						const store = transaction.objectStore(STORE_NAME);
						const existing = store.get(intent.idempotencyKey);
						existing.onerror = () => transaction.abort();
						existing.onsuccess = () => {
							const prior = existing.result;
							if (prior !== void 0) {
								if (sameIntent(prior, intent)) outcome = "existing";
								else reject(/* @__PURE__ */ new Error("offline-write idempotency conflict"));
								return;
							}
							const all = store.getAll();
							all.onerror = () => transaction.abort();
							all.onsuccess = () => {
								const writes = all.result;
								const bodyBytes = new TextEncoder().encode(intent.bodyJson).length;
								const total = writes.reduce((sum, write) => sum + write.bodyBytes, 0);
								if (writes.length >= config.maxEntries || total + bodyBytes > config.maxTotalBodyBytes) {
									reject(/* @__PURE__ */ new Error("offline-write quota exceeded"));
									return;
								}
								const createdAt = Math.max(Date.now(), ...writes.map((write) => write.createdAt + 1));
								store.put({
									...intent,
									createdAt,
									bodyBytes,
									deliveryState: "pending"
								}, intent.idempotencyKey);
								outcome = "queued";
							};
						};
					});
				} finally {
					db.close();
				}
			},
			async prepareFlush(binding) {
				const db = await openDatabase(config.databaseName);
				try {
					return await new Promise((resolve, reject) => {
						const transaction = db.transaction(STORE_NAME, "readwrite");
						let selected;
						transaction.oncomplete = () => selected === void 0 ? reject(/* @__PURE__ */ new Error("offline-write flush preparation incomplete")) : resolve(selected);
						transaction.onabort = () => reject(transaction.error ?? /* @__PURE__ */ new Error("offline-write flush preparation aborted"));
						transaction.onerror = () => reject(transaction.error ?? /* @__PURE__ */ new Error("offline-write flush preparation failed"));
						const store = transaction.objectStore(STORE_NAME);
						const all = store.getAll();
						all.onerror = () => transaction.abort();
						all.onsuccess = () => {
							const writes = all.result;
							const stale = writes.filter((write) => write.sessionBinding !== binding);
							for (const write of stale) store.delete(write.idempotencyKey);
							selected = {
								writes: writes.filter((write) => write.sessionBinding === binding && write.deliveryState === "pending").sort((left, right) => left.createdAt - right.createdAt),
								purged: stale.length
							};
						};
					});
				} finally {
					db.close();
				}
			},
			async remove(idempotencyKey) {
				const db = await openDatabase(config.databaseName);
				try {
					await new Promise((resolve, reject) => {
						const transaction = db.transaction(STORE_NAME, "readwrite");
						transaction.oncomplete = () => resolve();
						transaction.onabort = () => reject(transaction.error ?? /* @__PURE__ */ new Error("offline-write delete aborted"));
						transaction.onerror = () => reject(transaction.error ?? /* @__PURE__ */ new Error("offline-write delete failed"));
						transaction.objectStore(STORE_NAME).delete(idempotencyKey);
					});
				} finally {
					db.close();
				}
			},
			async markFailed(idempotencyKey, state) {
				const db = await openDatabase(config.databaseName);
				try {
					await new Promise((resolve, reject) => {
						const transaction = db.transaction(STORE_NAME, "readwrite");
						transaction.oncomplete = () => resolve();
						transaction.onabort = () => reject(transaction.error ?? /* @__PURE__ */ new Error("offline-write state update aborted"));
						transaction.onerror = () => reject(transaction.error ?? /* @__PURE__ */ new Error("offline-write state update failed"));
						const store = transaction.objectStore(STORE_NAME);
						const existing = store.get(idempotencyKey);
						existing.onerror = () => transaction.abort();
						existing.onsuccess = () => {
							const write = existing.result;
							if (write === void 0) {
								transaction.abort();
								return;
							}
							store.put({
								...write,
								deliveryState: state
							}, idempotencyKey);
						};
					});
				} finally {
					db.close();
				}
			},
			clear: () => deleteDatabase(config.databaseName)
		};
	}
	function sameIntent(stored, intent) {
		return stored.targetId === intent.targetId && stored.path === intent.path && stored.bodyJson === intent.bodyJson && stored.sessionBinding === intent.sessionBinding;
	}
	function openDatabase(databaseName) {
		return new Promise((resolve, reject) => {
			const request = indexedDB.open(databaseName, 1);
			request.onupgradeneeded = () => {
				request.result.createObjectStore(STORE_NAME);
			};
			request.onsuccess = () => resolve(request.result);
			request.onerror = () => reject(request.error ?? /* @__PURE__ */ new Error("offline-write database unavailable"));
			request.onblocked = () => reject(/* @__PURE__ */ new Error("offline-write database blocked"));
		});
	}
	function deleteDatabase(databaseName) {
		return new Promise((resolve, reject) => {
			const request = indexedDB.deleteDatabase(databaseName);
			request.onsuccess = () => resolve();
			request.onerror = () => reject(request.error ?? /* @__PURE__ */ new Error("offline-write database deletion failed"));
			request.onblocked = () => reject(/* @__PURE__ */ new Error("offline-write database deletion blocked"));
		});
	}
	//#endregion
	//#region ../sw-runtime/dist/worker/notification-target.js
	/**
	* Resolves `url` (as read from the notification's `data.url`, of unknown shape) against `scopeUrl`
	* (`registration.scope`, always absolute and ending in "/"). Falls back to `scopeUrl` whenever `url` is missing,
	* malformed, cross-origin, carries credentials, or resolves outside the scope — including `..` and percent-encoded
	* traversal, and a same-origin address that merely shares the scope's prefix (e.g. `/application/` vs `/app/`),
	* because the WHATWG URL parser normalises the target before this compares its serialized `href` against the scope.
	*/
	function resolveNotificationTarget(url, scopeUrl) {
		if (typeof url !== "string" || url.length === 0) return scopeUrl;
		let target;
		try {
			target = new URL(url, scopeUrl);
		} catch {
			return scopeUrl;
		}
		if (target.origin !== new URL(scopeUrl).origin) return scopeUrl;
		if (target.username.length > 0 || target.password.length > 0) return scopeUrl;
		if (!target.href.startsWith(scopeUrl)) return scopeUrl;
		return target.href;
	}
	//#endregion
	//#region ../sw-runtime/dist/shared/expiration-records.js
	var DATABASE_NAME = "workbox-expiration";
	var DATABASE_VERSION = 1;
	var OBJECT_STORE_NAME = "cache-entries";
	/**
	* Deletes every `workbox-expiration` record whose `cacheName` field satisfies `matches`. Never creates the database:
	* when `indexedDB.databases` reports it does not exist, this returns without opening anything; when `databases` is
	* unavailable, it opens without forcing a version bump and, if that open turns out to create the database (an
	* `upgradeneeded` fires), aborts the upgrade transaction so nothing is left behind and returns. A missing
	* `cache-entries` store (a `workbox-expiration` from some future/incompatible schema) is treated the same way.
	*/
	async function deleteExpirationRecords(matches) {
		if (!await mayExist()) return;
		const db = await openExistingDatabase();
		if (db === void 0) return;
		try {
			if (!db.objectStoreNames.contains(OBJECT_STORE_NAME)) return;
			await deleteMatchingRecords(db, matches);
		} finally {
			db.close();
		}
	}
	/** `false` only when `indexedDB.databases` is available and its listing does not include `workbox-expiration`. */
	async function mayExist() {
		if (typeof indexedDB.databases !== "function") return true;
		return (await indexedDB.databases()).some((entry) => entry.name === DATABASE_NAME);
	}
	/**
	* Opens `workbox-expiration` at its known version without creating it: an `upgradeneeded` firing means no such
	* database existed yet, so the transaction is aborted (which discards the database `open` would otherwise have just
	* created) and this resolves to `undefined` instead of a connection.
	*/
	function openExistingDatabase() {
		return new Promise((resolve, reject) => {
			let didNotExist = false;
			const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
			request.onupgradeneeded = () => {
				didNotExist = true;
				request.transaction?.abort();
			};
			request.onsuccess = () => resolve(request.result);
			request.onerror = () => {
				if (didNotExist) {
					resolve(void 0);
					return;
				}
				reject(request.error ?? /* @__PURE__ */ new Error("workbox-expiration open failed"));
			};
		});
	}
	/** One readwrite transaction: every entry whose `cacheName` matches is deleted while the cursor walks the store. */
	function deleteMatchingRecords(db, matches) {
		return new Promise((resolve, reject) => {
			const transaction = db.transaction(OBJECT_STORE_NAME, "readwrite");
			transaction.oncomplete = () => resolve();
			transaction.onerror = () => reject(transaction.error ?? /* @__PURE__ */ new Error("workbox-expiration record deletion failed"));
			transaction.onabort = () => reject(transaction.error ?? /* @__PURE__ */ new Error("workbox-expiration record deletion aborted"));
			const request = transaction.objectStore(OBJECT_STORE_NAME).openCursor();
			request.onerror = () => reject(request.error ?? /* @__PURE__ */ new Error("workbox-expiration cursor failed"));
			request.onsuccess = () => {
				const cursor = request.result;
				if (cursor === null) return;
				const cacheName = cursor.value.cacheName;
				if (typeof cacheName === "string" && matches(cacheName)) cursor.delete();
				cursor.continue();
			};
		});
	}
	//#endregion
	//#region ../sw-runtime/dist/worker/runtime-cleanup.js
	/**
	* Deletes the pages runtime cache outright, and every data runtime cache except `keep` (when given), then deletes
	* the workbox-expiration record of every cache name that same rule matches — computed from `runtimeCache` and
	* `keep`, not from `caches.keys()`, so a record whose cache was already gone (e.g. from a previous run that failed
	* after the cache delete) is still reached. Activation passes the current digest's data cache as `keep` so only
	* stale configurations are purged; logout passes nothing, so every data cache — current digest included — is
	* removed. A record-deletion failure rejects, same as a cache-deletion failure, so callers that gate on this (the
	* logout handshake) see it.
	*/
	async function deleteRuntimeCaches(scope, runtimeCache, keep) {
		await scope.caches.delete(runtimeCache.pagesCacheName);
		for (const name of await scope.caches.keys()) if (name.startsWith(runtimeCache.dataCacheNamePrefix) && name !== keep) await scope.caches.delete(name);
		await deleteExpirationRecords((name) => name === runtimeCache.pagesCacheName || name.startsWith(runtimeCache.dataCacheNamePrefix) && name !== keep);
	}
	/** The one data cache activation must keep: the current digest's, only when the runtime cache is enabled. */
	function currentDataCacheName(runtimeCache) {
		return runtimeCache.enabled ? runtimeCache.dataCacheName : void 0;
	}
	//#endregion
	//#region ../sw-runtime/dist/worker/handlers.js
	var PENDING_SIGNAL_LIMIT = 16;
	var PENDING_SIGNAL_TTL_MS = 3e4;
	/**
	* Registers `install`, `activate`, `fetch`, `message`, `push` and `notificationclick`, and nothing else. The worker
	* never calls `skipWaiting` on its own (updates are prompted) and never claims clients. `push` and
	* `notificationclick` are always on: see ADR-0021 for why a fixed pair of listeners has no observable effect on an
	* application that never subscribes to push.
	*/
	function attachPlatformWorker({ scope, config, engine, createRuntimeCacheEngine: runtimeCacheEngineFactory, registerRuntimeCacheQuotaCleanup: registerQuotaCleanup, offlineWriteStore: offlineWriteStoreOverride }) {
		const origin = new URL(scope.location.href).origin;
		const router = createRouter({
			config,
			manifestUrls: engine.urls(),
			origin
		});
		const offlineWriteStore = config.offlineWrites.enabled ? offlineWriteStoreOverride ?? createOfflineWriteStore(config.offlineWrites) : void 0;
		const inFlightFlushes = /* @__PURE__ */ new Map();
		const runtimeEngines = config.runtimeCache.enabled ? buildRuntimeEngines(config.runtimeCache, config.networkTimeoutSeconds, requireRuntimeCacheEngineFactory(runtimeCacheEngineFactory)) : void 0;
		if (config.runtimeCache.enabled && registerQuotaCleanup !== void 0) registerQuotaCleanup(() => {
			if (scope.registration.installing !== null) return void 0;
			return deleteRuntimeCaches(scope, config.runtimeCache).catch(() => void 0);
		});
		const pendingSignals = createPendingSignalStore();
		scope.addEventListener("install", (event) => {
			engine.install(event).catch(() => void 0);
		});
		scope.addEventListener("activate", (event) => {
			engine.activate(event);
			event.waitUntil(deleteRuntimeCaches(scope, config.runtimeCache, currentDataCacheName(config.runtimeCache)).catch(() => void 0));
		});
		scope.addEventListener("fetch", (event) => {
			const decision = router.decide({
				method: event.request.method,
				url: event.request.url,
				navigation: event.request.mode === "navigate",
				range: event.request.headers.has("range"),
				authorization: event.request.headers.has("authorization")
			});
			if (decision.kind === "passthrough") return;
			if (decision.kind === "precache") {
				event.respondWith(fromPrecache(scope, engine, decision.manifestUrl, event.request));
				return;
			}
			if (decision.kind === "runtime") {
				event.respondWith(respondFromRuntimeCache(scope, engine, runtimeEngineFor(runtimeEngines, decision), decision, event, pendingSignals));
				return;
			}
			event.respondWith(navigate(scope, engine, decision.fallbacks, event.request, config.networkTimeoutSeconds));
		});
		scope.addEventListener("message", (event) => {
			if (!isSameOriginWindow(event.source, origin)) return;
			if (isSkipWaitingMessage(event.data)) {
				event.waitUntil(scope.skipWaiting());
				return;
			}
			if (isRuntimeCachePendingMessage(event.data)) {
				const [port, ...rest] = event.ports;
				if (port === void 0 || rest.length !== 0) return;
				const clientId = windowClientId(event.source);
				if (clientId === void 0) return;
				replyPending(port, pendingSignals.take(clientId));
				return;
			}
			if (!isOfflineWriteMessage(event.data)) return;
			const [port, ...rest] = event.ports;
			if (port === void 0 || rest.length !== 0) return;
			if (event.data.type === "pwa:offline-write:clear") {
				event.waitUntil(clear(event.data, offlineWriteStore, port, scope, config.runtimeCache));
				return;
			}
			if (offlineWriteStore === void 0) return;
			if (event.data.type === "pwa:offline-write:enqueue") event.waitUntil(enqueue(event.data, config, origin, offlineWriteStore, port));
			if (event.data.type === "pwa:offline-write:flush") event.waitUntil(flush(event.data, config, origin, offlineWriteStore, inFlightFlushes, port, scope.fetch));
		});
		scope.addEventListener("push", (event) => {
			const payload = event.data === null ? null : validatePushPayload(event.data.text());
			if (payload === null) return;
			const options = { data: {
				url: payload.url ?? null,
				data: payload.data ?? null
			} };
			if (payload.body !== void 0) options.body = payload.body;
			if (payload.tag !== void 0) options.tag = payload.tag;
			event.waitUntil(scope.registration.showNotification(payload.title, options));
		});
		scope.addEventListener("notificationclick", (event) => {
			event.notification.close();
			const target = resolveNotificationTarget(readNotificationUrl(event.notification.data), scope.registration.scope);
			event.waitUntil(focusOrOpen(scope, target));
		});
	}
	async function clear(message, store, port, scope, runtimeCache) {
		try {
			await store?.clear();
		} catch {
			reply(port, message.requestId, "rejected", "offline-write.storage");
			return;
		}
		if (runtimeCache.enabled) try {
			await deleteRuntimeCaches(scope, runtimeCache);
		} catch {
			reply(port, message.requestId, "rejected", "offline-write.storage");
			return;
		}
		else await deleteRuntimeCaches(scope, runtimeCache).catch(() => void 0);
		replyClear(port, message.requestId);
	}
	async function flush(message, config, origin, store, inFlightFlushes, port, send) {
		const checked = validateOfflineWriteFlush(message, config);
		if (!checked.ok) return reply(port, message.requestId, "rejected", checked.code);
		try {
			const result = await flushOnce(store, checked.binding, origin, send, inFlightFlushes);
			replyFlush(port, message.requestId, result);
		} catch {
			reply(port, message.requestId, "rejected", "offline-write.storage");
		}
	}
	/**
	* Starts `flushOfflineWrites` for `binding` unless one is already in flight. A request that arrives while the
	* in-flight round is still reading its snapshot joins it and shares its exact result, unchanged from the original
	* single-flight behaviour (R5). A request that arrives after that read has resolved — the round is only still
	* sending — cannot observe writes enqueued from this point on, so instead of joining it is coalesced into exactly
	* one trailing round that starts once the current round finishes (N2); every such late request shares that same
	* trailing round's result. Once a round settles with nothing coalesced into it, its entry is removed so the next
	* flush request for `binding` starts a fresh pass.
	*/
	function flushOnce(store, binding, origin, send, inFlightFlushes) {
		const state = inFlightFlushes.get(binding);
		if (state === void 0) return startFlushRound(store, binding, origin, send, inFlightFlushes);
		if (!state.readPrepared) return state.active;
		if (state.trailing === void 0) state.trailing = state.active.then(() => startFlushRound(store, binding, origin, send, inFlightFlushes), () => startFlushRound(store, binding, origin, send, inFlightFlushes));
		return state.trailing;
	}
	function startFlushRound(store, binding, origin, send, inFlightFlushes) {
		const state = { readPrepared: false };
		const active = flushOfflineWrites(store, binding, origin, send, () => {
			state.readPrepared = true;
		});
		state.active = active;
		inFlightFlushes.set(binding, state);
		active.finally(() => {
			if (inFlightFlushes.get(binding) === state && state.trailing === void 0) inFlightFlushes.delete(binding);
		}).catch(() => void 0);
		return active;
	}
	async function enqueue(message, config, origin, store, port) {
		const checked = validateOfflineWriteEnqueue(message, config, origin);
		if (!checked.ok) return reply(port, message.requestId, "rejected", checked.code);
		try {
			reply(port, message.requestId, await store.enqueue(checked.value));
		} catch {
			reply(port, message.requestId, "rejected", "offline-write.storage");
		}
	}
	function reply(port, requestId, status, code) {
		try {
			port.postMessage(code === void 0 ? {
				type: "pwa:offline-write:result",
				version: 1,
				requestId,
				status
			} : {
				type: "pwa:offline-write:result",
				version: 1,
				requestId,
				status,
				code
			});
		} catch {}
	}
	function replyFlush(port, requestId, result) {
		try {
			port.postMessage({
				type: "pwa:offline-write:result",
				version: 1,
				requestId,
				status: "flushed",
				...result
			});
		} catch {}
	}
	function replyClear(port, requestId) {
		try {
			port.postMessage({
				type: "pwa:offline-write:result",
				version: 1,
				requestId,
				status: "cleared"
			});
		} catch {}
	}
	/** Reads `data.url` without ever invoking an accessor: anything other than a plain object with a string data property is undefined. */
	function readNotificationUrl(data) {
		if (typeof data !== "object" || data === null || Array.isArray(data)) return void 0;
		const prototype = Object.getPrototypeOf(data);
		if (prototype !== Object.prototype && prototype !== null) return void 0;
		const descriptor = Object.getOwnPropertyDescriptor(data, "url");
		if (descriptor === void 0 || !("value" in descriptor) || typeof descriptor.value !== "string") return void 0;
		return descriptor.value;
	}
	/** Focuses a same-origin, same-scope window already showing `target`, otherwise opens it. Never navigates an existing window. */
	async function focusOrOpen(scope, target) {
		try {
			const existing = (await scope.clients.matchAll({
				type: "window",
				includeUncontrolled: true
			})).find((client) => client.url === target);
			if (existing !== void 0) {
				await existing.focus();
				return;
			}
			await scope.clients.openWindow(target);
		} catch {}
	}
	/** A precached URL: the cache answers; a missing entry falls back to the network rather than failing the request. */
	async function fromPrecache(scope, engine, manifestUrl, request) {
		return await engine.match(manifestUrl) ?? await scope.fetch(request);
	}
	/**
	* Navigation: the network answers whenever it responds at all, including 4xx and 5xx; offline uses the fallbacks.
	* When `networkTimeoutSeconds` is set (ADR-0038) and the network has not answered within that many seconds, the
	* fallbacks are consulted early: a match is returned immediately and the still-pending network result is left to
	* settle on its own (its rejection is swallowed, and navigate() never writes to a cache either way, so nothing is
	* cached from it). With no matching fallback, navigate() keeps waiting for the network exactly as it would without a
	* timeout — a timeout must never turn a request that would have succeeded into an error.
	*/
	async function navigate(scope, engine, fallbacks, request, networkTimeoutSeconds) {
		if (networkTimeoutSeconds === void 0) {
			try {
				const response = await scope.fetch(request);
				if (response.type !== "error") return response;
			} catch {}
			return fallbackResponse(engine, fallbacks);
		}
		const networkPromise = scope.fetch(request);
		let timer;
		const timedOut = await new Promise((resolve) => {
			timer = setTimeout(() => resolve(true), networkTimeoutSeconds * 1e3);
			networkPromise.then(() => resolve(false), () => resolve(false));
		});
		if (timer !== void 0) clearTimeout(timer);
		if (!timedOut) {
			try {
				const response = await networkPromise;
				if (response.type !== "error") return response;
			} catch {}
			return fallbackResponse(engine, fallbacks);
		}
		try {
			for (const candidate of fallbacks) {
				const fallback = await engine.match(candidate);
				if (fallback !== void 0) return fallback;
			}
		} catch {}
		try {
			const response = await networkPromise;
			if (response.type !== "error") return response;
		} catch {}
		return fallbackResponse(engine, fallbacks);
	}
	/** The first precached fallback that exists, in order, or a network error when none does. */
	async function fallbackResponse(engine, fallbacks) {
		for (const candidate of fallbacks) {
			const response = await engine.match(candidate);
			if (response !== void 0) return response;
		}
		return Response.error();
	}
	function isSameOriginWindow(source, origin) {
		if (source === null || !("type" in source) || source.type !== "window") return false;
		return URL.canParse(source.url) && new URL(source.url).origin === origin;
	}
	/** The requesting window client's id, read without invoking an accessor other than the plain property itself. */
	function windowClientId(source) {
		if (source === null || typeof source !== "object" || !("id" in source)) return void 0;
		const id = source.id;
		return typeof id === "string" ? id : void 0;
	}
	function replyPending(port, served) {
		try {
			port.postMessage({
				type: "pwa:runtime-cache:pending-result",
				version: 1,
				served
			});
		} catch {}
	}
	function requireRuntimeCacheEngineFactory(factory) {
		if (factory === void 0) throw new Error("attachPlatformWorker: config.runtimeCache.enabled requires a createRuntimeCacheEngine factory");
		return factory;
	}
	/**
	* Builds at most three runtime-cache engines, one per (cache, strategy) pair actually used, the first time each is
	* needed. `networkTimeoutSeconds` (ADR-0038), when set, is passed through only for the two network-first engines —
	* "pages" and "data-network-first" — never for "data-stale-while-revalidate", which never waits on the network.
	*/
	function buildRuntimeEngines(runtimeCache, networkTimeoutSeconds, factory) {
		const built = /* @__PURE__ */ new Map();
		const reported = /* @__PURE__ */ new Set();
		return (key) => {
			const existing = built.get(key);
			if (existing !== void 0) return existing;
			const engine = key === "pages" ? factory({
				cacheName: runtimeCache.pagesCacheName,
				strategy: "network-first",
				maxEntries: runtimeCache.maxEntries,
				maxAgeSeconds: runtimeCache.maxAgeSeconds,
				admit: (response) => admitAndReport(response, key, reported, {
					resourceClass: "navigation-public-dynamic",
					strategy: "network-first",
					maxEntryBytes: runtimeCache.maxEntryBytes
				}),
				...networkTimeoutSeconds === void 0 ? {} : { networkTimeoutSeconds }
			}) : factory({
				cacheName: runtimeCache.dataCacheName,
				strategy: key === "data-network-first" ? "network-first" : "stale-while-revalidate",
				maxEntries: runtimeCache.maxEntries,
				maxAgeSeconds: runtimeCache.maxAgeSeconds,
				admit: (response) => admitAndReport(response, key, reported, {
					resourceClass: "public-data",
					strategy: key === "data-network-first" ? "network-first" : "stale-while-revalidate",
					maxEntryBytes: runtimeCache.maxEntryBytes
				}),
				...key === "data-network-first" && networkTimeoutSeconds !== void 0 ? { networkTimeoutSeconds } : {}
			});
			built.set(key, engine);
			return engine;
		};
	}
	/**
	* Runs the admission check and, the first time an (engine, reason) pair rejects a response in this worker's lifetime,
	* reports it with `console.warn` (spec.public-read-cache "响应准入", review risk R8). The report is a debugging aid only:
	* it names the reason and the response's path — never its query string — plus the `Vary` value when that was the
	* cause, and never changes the admission result.
	*/
	async function admitAndReport(response, key, reported, options) {
		const reason = await runtimeAdmissionRejection(response, options);
		if (reason === void 0) return true;
		const reportKey = `${key}:${reason}`;
		if (!reported.has(reportKey)) {
			reported.add(reportKey);
			console.warn(rejectionMessage(response, reason));
		}
		return false;
	}
	function rejectionMessage(response, reason) {
		return `[pwa-platform] runtime cache did not store ${URL.canParse(response.url) ? new URL(response.url).pathname : "(unknown path)"}: ${reason}${reason === "vary" ? ` (Vary: ${response.headers.get("vary") ?? ""})` : ""}. Further ${reason} rejections from this cache are not reported.`;
	}
	/** `decide()` only ever returns a `"runtime"` decision once `config.runtimeCache.enabled` made `runtimeEngines` non-undefined. */
	function runtimeEngineFor(runtimeEngines, decision) {
		if (runtimeEngines === void 0) throw new Error("Runtime-cache decision without a runtime-cache configuration");
		return runtimeEngines(decision.cache === "pages" ? "pages" : decision.strategy === "network-first" ? "data-network-first" : "data-stale-while-revalidate");
	}
	/**
	* Runs one runtime-cache decision. On success, a cache-served response's signal is delivered — posted straight to
	* the requesting client for a subresource, or stashed by `event.resultingClientId` for a navigation, since a
	* navigation's own client may not exist yet to receive a direct post (spec "页面信号", T1). On failure (network down
	* and nothing cached), a page decision falls back exactly like `navigate()`; a data decision rejects so the page
	* sees a network error, matching the spec's "read-only cache, no offline story for data" stance.
	*/
	async function respondFromRuntimeCache(scope, precacheEngine, runtimeEngine, decision, event, pendingSignals) {
		const result = await runtimeEngine.handle(event).catch((error) => {
			if (decision.cache === "pages") return void 0;
			throw error;
		});
		if (result === void 0) return fallbackResponse(precacheEngine, decision.fallbacks);
		if (result.servedFromCache !== null) {
			const signal = {
				url: requestPath(event.request.url),
				cachedAt: result.servedFromCache.cachedAt,
				reason: result.servedFromCache.reason
			};
			if (decision.cache === "pages") pendingSignals.store(event.resultingClientId, signal);
			else event.waitUntil(postServedFromCacheSignal(scope, event.clientId, signal));
		}
		return result.response;
	}
	function requestPath(url) {
		const { pathname, search } = new URL(url);
		return `${pathname}${search}`;
	}
	async function postServedFromCacheSignal(scope, clientId, signal) {
		const client = await scope.clients.get(clientId);
		if (client === void 0) return;
		try {
			client.postMessage({
				type: "pwa:runtime-cache:served",
				version: 1,
				...signal
			});
		} catch {}
	}
	/** At most 16 pending navigation signals, oldest evicted first; a signal older than 30s is dropped when taken. */
	function createPendingSignalStore() {
		const entries = /* @__PURE__ */ new Map();
		return {
			store(clientId, signal) {
				entries.delete(clientId);
				entries.set(clientId, {
					signal,
					storedAt: Date.now()
				});
				while (entries.size > PENDING_SIGNAL_LIMIT) {
					const oldest = entries.keys().next().value;
					if (oldest === void 0) break;
					entries.delete(oldest);
				}
			},
			take(clientId) {
				const entry = entries.get(clientId);
				entries.delete(clientId);
				if (entry === void 0 || Date.now() - entry.storedAt > PENDING_SIGNAL_TTL_MS) return null;
				return entry.signal;
			}
		};
	}
	//#endregion
	//#region ../sw-runtime/dist/worker/index.js
	/**
	* Registers the platform worker: it precaches the plan's entries through the engine port, serves exact precache
	* hits, answers navigations network first with the plan's offline fallbacks, and leaves every other request to the
	* network. It skips waiting only when a page confirms an update.
	*/
	function registerPlatformWorker({ scope, config, manifest }) {
		const validated = validatePlatformWorkerConfig(config);
		attachPlatformWorker({
			scope,
			config: validated,
			engine: createPrecacheEngine({
				cacheName: validated.precacheCacheName,
				entries: manifest
			}),
			createRuntimeCacheEngine,
			registerRuntimeCacheQuotaCleanup
		});
	}
	//#endregion
	//#region ../sw-runtime/dist/entries/platform-worker-entry.js
	registerPlatformWorker({
		scope: self,
		config: {"kind":"platform","version":1,"scope":"/app/","precacheCacheName":"pwa:vitefixture:production:r1:precache","requestBaselineDenials":["non-get","cross-origin","no-store","opaque-response","redirect","websocket","unclassified"],"pathRules":[{"pathPrefix":"/app/offline.html","action":"cache-first"},{"pathPrefix":"/app/index.html","action":"cache-first"},{"pathPrefix":"/app/assets","action":"cache-first"},{"pathPrefix":"/app","action":"network-first"}],"offlineFallback":{"enabled":true,"path":"/app/offline.html"},"updateMode":"prompt","offlineWrites":{"enabled":false},"runtimeCache":{"enabled":false,"pagesCacheName":"pwa:vitefixture:production:r1:runtime-pages","dataCacheNamePrefix":"pwa:vitefixture:production:r1:runtime-data-"}},
		manifest: [{"url":"/app/assets/index-C9LxKNc3.js","revision":null},{"url":"/app/assets/index-D9tTKZML.css","revision":null},{"url":"/app/index.html","revision":"XK-UvfFmyqfGLpKhvFQh9aj4wK9HGeJUV9s8bqVZ1XQ"},{"url":"/app/offline.html","revision":"EU0htz8F4uPxYXAndGXdtPIqoc60s0kUqZHUeCtbZ5o"}]
	});
	//#endregion
})();
