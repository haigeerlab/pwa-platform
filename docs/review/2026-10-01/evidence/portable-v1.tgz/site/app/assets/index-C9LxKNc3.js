//#region \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
//#endregion
//#region \0virtual:pwa-config
var _virtual_pwa_config_default = Object.freeze({
	"appId": "vitefixture",
	"scope": "/app/",
	"serviceWorkerUrl": "/app/sw.js",
	"updateMode": "prompt",
	"installEnabled": true
});
//#endregion
//#region ../client-runtime/dist/client/events.js
/** Builds an envelope contracts' `readLifecycleEvent` accepts. */
function clientEvent(type, appId, metadata) {
	return {
		version: 1,
		type,
		timestamp: (/* @__PURE__ */ new Date()).toISOString(),
		appId,
		metadata
	};
}
//#endregion
//#region ../sw-runtime/dist/messages/index.js
var SKIP_WAITING_MESSAGE = Object.freeze({ type: "pwa:skip-waiting" });
/** Matches one closed clear acknowledgement without reading page- or worker-provided accessors. */
function isOfflineWriteClearResult(value, requestId) {
	const result = dataObject(value, [
		"type",
		"version",
		"requestId",
		"status"
	]);
	return result !== void 0 && read(result, "type") === "pwa:offline-write:result" && read(result, "version") === 1 && read(result, "requestId") === requestId && read(result, "status") === "cleared";
}
/** Matches only the closed served signal. Reads never invoke a page-provided accessor. */
function isRuntimeCacheServedMessage(value) {
	const message = dataObject(value, [
		"type",
		"version",
		"url",
		"cachedAt",
		"reason"
	]);
	if (message === void 0 || read(message, "type") !== "pwa:runtime-cache:served" || read(message, "version") !== 1) return false;
	if (typeof read(message, "url") !== "string" || typeof read(message, "cachedAt") !== "number") return false;
	return isRuntimeCacheReason(read(message, "reason"));
}
/** Matches only the closed pending-result reply. Reads never invoke a page-provided accessor. */
function isRuntimeCachePendingResult(value) {
	const message = dataObject(value, [
		"type",
		"version",
		"served"
	]);
	if (message === void 0 || read(message, "type") !== "pwa:runtime-cache:pending-result" || read(message, "version") !== 1) return false;
	const served = read(message, "served");
	if (served === null) return true;
	const entry = dataObject(served, [
		"url",
		"cachedAt",
		"reason"
	]);
	if (entry === void 0) return false;
	if (typeof read(entry, "url") !== "string" || typeof read(entry, "cachedAt") !== "number") return false;
	return isRuntimeCacheReason(read(entry, "reason"));
}
function isRuntimeCacheReason(value) {
	return value === "network-failed" || value === "network-timeout" || value === "stale-while-revalidate";
}
function dataObject(value, keys) {
	const record = plainDataObject(value);
	if (record === void 0) return void 0;
	const actual = Reflect.ownKeys(record);
	if (actual.length !== keys.length || !keys.every((key) => actual.includes(key))) return void 0;
	return record;
}
function plainDataObject(value) {
	if (typeof value !== "object" || value === null || Array.isArray(value)) return void 0;
	const prototype = Object.getPrototypeOf(value);
	if (prototype !== Object.prototype && prototype !== null) return void 0;
	if (Reflect.ownKeys(value).some((key) => typeof key !== "string" || !hasDataProperty(value, key))) return void 0;
	return value;
}
function hasDataProperty(value, key) {
	const descriptor = Object.getOwnPropertyDescriptor(value, key);
	return descriptor !== void 0 && "value" in descriptor;
}
function read(value, key) {
	const descriptor = Object.getOwnPropertyDescriptor(value, key);
	return descriptor !== void 0 && "value" in descriptor ? descriptor.value : void 0;
}
//#endregion
//#region ../client-runtime/dist/shared/config.js
var CONFIG_KEYS = [
	"appId",
	"scope",
	"serviceWorkerUrl",
	"updateMode",
	"installEnabled"
];
var PATH_BASE = "https://client-runtime.invalid";
/**
* Validates a client config and returns a fresh copy with keys in canonical order. Messages name fields only, never
* the value that failed.
*/
function validateClientConfig(value) {
	const config = plainObject(value, "config");
	exactKeys(config, CONFIG_KEYS, "config");
	const appId = config["appId"];
	if (typeof appId !== "string" || appId === "") fail("config.appId must be a non-empty string");
	const scope = canonicalPath(config["scope"], "config.scope");
	if (!scope.endsWith("/")) fail("config.scope must end with \"/\"");
	const serviceWorkerUrl = canonicalPath(config["serviceWorkerUrl"], "config.serviceWorkerUrl");
	if (!serviceWorkerUrl.startsWith(scope)) fail("config.serviceWorkerUrl must be inside config.scope");
	if (config["updateMode"] !== "prompt") fail("config.updateMode must be \"prompt\"");
	const installEnabled = config["installEnabled"];
	if (typeof installEnabled !== "boolean") fail("config.installEnabled must be a boolean");
	return {
		appId,
		scope,
		serviceWorkerUrl,
		updateMode: "prompt",
		installEnabled
	};
}
function fail(detail) {
	throw new Error(`Invalid client-runtime config: ${detail}`);
}
function plainObject(value, label) {
	const prototype = typeof value === "object" && value !== null ? Object.getPrototypeOf(value) : void 0;
	if (Array.isArray(value) || prototype !== Object.prototype && prototype !== null) fail(`${label} must be a plain object`);
	return value;
}
function exactKeys(record, keys, label) {
	if (Reflect.ownKeys(record).length !== keys.length || !keys.every((key) => Object.hasOwn(record, key))) fail(`${label} must have exactly the fields ${keys.join(", ")}`);
}
/**
* The rule contracts' `isCanonicalPath` applies to plan paths: an absolute path already in WHATWG URL serialized
* form, without "//", backslashes, query, fragment or characters the URL parser would change.
*/
function canonicalPath(value, label) {
	if (!(typeof value === "string" && value.startsWith("/") && !value.includes("//") && !value.includes("\\") && URL.canParse(value, PATH_BASE) && new URL(value, PATH_BASE).pathname === value)) fail(`${label} must be a canonical absolute path`);
	return value;
}
//#endregion
//#region ../client-runtime/dist/client/update-check.js
/** The lower bound keeps automatic checks from turning `serviceWorkerUrl` into a high-frequency poll target. */
var MIN_INTERVAL_MS = 6e4;
/** The largest delay `setTimeout` accepts before it wraps. */
var MAX_INTERVAL_MS = 2147483647;
/** Validates `options.updateCheck.intervalMs`. Throws for anything but an integer in range; never echoes the value. */
function validateUpdateCheckIntervalMs(intervalMs) {
	if (typeof intervalMs !== "number" || !Number.isInteger(intervalMs) || intervalMs < MIN_INTERVAL_MS || intervalMs > MAX_INTERVAL_MS) throw new Error(`options.updateCheck.intervalMs must be an integer between ${MIN_INTERVAL_MS} and ${MAX_INTERVAL_MS}`);
	return intervalMs;
}
/**
* Builds a chained-timer scheduler: the next tick is armed only once the previous automatic check has settled, so
* checks never overlap. A tick that lands while the page is hidden is skipped and remembered as "owed"; becoming
* visible again runs a check immediately when one is owed, or when a full interval has already passed since the
* last check started — the latter covers the gap between that check's start and the moment its own next tick would
* fire, which is otherwise a window where nothing is "owed" yet the interval has already elapsed.
*/
function createUpdateScheduler(options) {
	const { intervalMs, document, runCheck, track } = options;
	let started = false;
	let checking = false;
	let owed = false;
	let lastCheckStart = 0;
	/**
	* Bumped by every start() and stop(). A check that began under an earlier generation belongs to a schedule that
	* has since been stopped (and possibly restarted), so when it settles it must leave the current one alone.
	*/
	let generation = 0;
	let untrackTimer;
	let untrackVisibility;
	function clearTimer() {
		untrackTimer?.();
		untrackTimer = void 0;
	}
	function armTimer() {
		clearTimer();
		const timer = setTimeout(onTick, intervalMs);
		untrackTimer = track(() => clearTimeout(timer));
	}
	function onTick() {
		clearTimer();
		if (document.visibilityState !== "visible") {
			owed = true;
			return;
		}
		runAutomaticCheck();
	}
	function onVisibilityChange() {
		if (document.visibilityState !== "visible" || checking) return;
		if (!owed && Date.now() - lastCheckStart < intervalMs) return;
		clearTimer();
		runAutomaticCheck();
	}
	async function runAutomaticCheck() {
		if (checking) return;
		checking = true;
		lastCheckStart = Date.now();
		const startedIn = generation;
		try {
			await runCheck();
		} catch {}
		if (startedIn !== generation) return;
		checking = false;
		owed = false;
		armTimer();
	}
	return {
		start() {
			if (started) return;
			started = true;
			generation += 1;
			owed = false;
			lastCheckStart = Date.now();
			document.addEventListener("visibilitychange", onVisibilityChange);
			untrackVisibility = track(() => document.removeEventListener("visibilitychange", onVisibilityChange));
			armTimer();
		},
		stop() {
			if (!started) return;
			started = false;
			generation += 1;
			checking = false;
			owed = false;
			clearTimer();
			untrackVisibility?.();
			untrackVisibility = void 0;
		}
	};
}
//#endregion
//#region ../client-runtime/dist/client/facade.js
/** How long `applyUpdate` waits for the confirmed worker to take control before giving up. */
var TAKEOVER_TIMEOUT_MS = 1e4;
var CLEAR_TIMEOUT_MS = 1e4;
/** How long the pending-served query waits for the worker's reply (same bound as the offline-write clear handshake). */
var RUNTIME_CACHE_PENDING_TIMEOUT_MS = 1e4;
/** Validates the config and returns a facade bound to it. Throws for an invalid config. */
function createPwaClient(options) {
	const config = validateClientConfig(options.config);
	const container = options.container ?? defaultContainer();
	const updateCheckIntervalMs = options.updateCheck !== void 0 ? validateUpdateCheckIntervalMs(options.updateCheck.intervalMs) : void 0;
	const updateCheckDocument = updateCheckIntervalMs !== void 0 ? options.document ?? defaultDocument() : void 0;
	const createMessageChannel = options.messageChannel ?? (() => new MessageChannel());
	const listeners = /* @__PURE__ */ new Set();
	/**
	* Everything dispose() must undo: listener removals and timer cancellations. A set rather than a list, because
	* waits and registrations are also undone individually (a settled takeover, a logout) and must not pile up here
	* for the lifetime of the facade.
	*/
	const teardown = /* @__PURE__ */ new Set();
	let registration;
	let stopWatching;
	/** Removes the runtime-cache-served listener `register()` attached; tied to the registration's lifetime, not the facade's. */
	let stopRuntimeCacheMessages;
	let installPrompt;
	/** The worker `update-waiting` was last announced for, so the two detection paths cannot announce it twice. */
	let announcedWaiting;
	/** A `checkForUpdate()` in flight, shared by concurrent callers; cleared once it settles either way. */
	let pendingCheck;
	let nextClearRequestId = 1;
	let disposed = false;
	function alive() {
		if (disposed) throw new Error("This PWA client has been disposed");
	}
	/** Registers an undo callback and returns a handle that runs it once and forgets it. */
	function track(undo) {
		teardown.add(undo);
		return () => {
			if (teardown.delete(undo)) undo();
		};
	}
	function emit(type, metadata) {
		const event = clientEvent(type, config.appId, metadata);
		for (const listener of [...listeners]) try {
			listener(event);
		} catch {}
	}
	/**
	* An update is a worker waiting while another one still controls the page. On a first visit nothing controls the
	* page yet, so the worker that just installed is not an update and must not prompt anyone.
	*/
	function announceWaiting(waiting) {
		if (waiting === null || container.controller === null || waiting === announcedWaiting) return;
		announcedWaiting = waiting;
		emit("update-waiting", {});
	}
	/**
	* Watches one registration for versions that install later in this page's lifetime. Returns a handle that removes
	* every listener it added, so logging out can stop watching a registration that no longer exists.
	*/
	function watchForUpdates(current) {
		announceWaiting(current.waiting);
		const undoAll = [];
		const onControllerChange = () => {
			if (announcedWaiting === void 0) return;
			announcedWaiting = void 0;
			emit("update-applied", {});
		};
		container.addEventListener("controllerchange", onControllerChange);
		undoAll.push(track(() => container.removeEventListener("controllerchange", onControllerChange)));
		const watchInstalling = (installing) => {
			if (installing === null) return;
			const onStateChange = () => {
				if (installing.state === "installed") announceWaiting(installing);
			};
			installing.addEventListener("statechange", onStateChange);
			undoAll.push(track(() => installing.removeEventListener("statechange", onStateChange)));
		};
		const onUpdateFound = () => watchInstalling(current.installing);
		current.addEventListener("updatefound", onUpdateFound);
		undoAll.push(track(() => current.removeEventListener("updatefound", onUpdateFound)));
		watchInstalling(current.installing);
		return () => {
			for (const undo of undoAll.splice(0)) undo();
		};
	}
	/**
	* Waits for another worker to take control. `applyUpdate` subscribes before it posts the confirmation; today the
	* two run in one synchronous block, so no `controllerchange` could arrive between them either way, but keeping
	* the subscription first means an `await` added between them later cannot open that gap.
	*
	* The listener and the timer are registered with `track`, so dispose() reaches this wait too. Without that, a
	* facade retired mid-update would keep a timer alive and reject ten seconds later into a promise the application
	* had already stopped awaiting — an unhandled rejection with no owner.
	*/
	function takeover() {
		let cancel = () => void 0;
		return {
			settled: new Promise((resolve, reject) => {
				const finish = (settle) => () => {
					clearTimeout(timer);
					container.removeEventListener("controllerchange", onControllerChange);
					teardown.delete(stop);
					settle();
				};
				const onControllerChange = () => finish(resolve)();
				const timer = setTimeout(finish(() => reject(/* @__PURE__ */ new Error("The confirmed worker did not take control in time"))), TAKEOVER_TIMEOUT_MS);
				const stop = finish(() => reject(/* @__PURE__ */ new Error("Stopped waiting for the worker to take control")));
				cancel = stop;
				container.addEventListener("controllerchange", onControllerChange);
				teardown.add(stop);
			}),
			cancel: () => cancel()
		};
	}
	/**
	* The actual check: fetch the registration, ask the browser to re-fetch the worker script, then read what it
	* left behind. `installing`/`waiting` are read after `update()` settles, not derived from its resolution value —
	* the browser API itself carries no result beyond "the check finished".
	*/
	async function performUpdateCheck() {
		const current = await container.getRegistration(config.scope);
		if (current === void 0) return "unavailable";
		await current.update();
		return current.installing !== null || current.waiting !== null ? "update-available" : "up-to-date";
	}
	/**
	* The coalescing entry point both `checkForUpdate()` and the automatic scheduler call, so a manual and an
	* automatic check in flight at the same time share one `update()` call instead of issuing two.
	*/
	function sharedUpdateCheck() {
		if (pendingCheck === void 0) {
			pendingCheck = performUpdateCheck();
			pendingCheck.then(() => pendingCheck = void 0, () => pendingCheck = void 0);
		}
		return pendingCheck;
	}
	/** Clears worker-owned sensitive queue state through a one-shot port before the registration can disappear. */
	function clearOfflineWrites(worker) {
		const requestId = `logout-${nextClearRequestId++}`;
		const channel = createMessageChannel();
		return new Promise((resolve, reject) => {
			let settled = false;
			const finish = (settle) => {
				if (settled) return;
				settled = true;
				clearTimeout(timeout);
				channel.port1.close();
				settle();
			};
			const timeout = setTimeout(() => finish(() => reject(/* @__PURE__ */ new Error("The worker did not acknowledge offline-write cleanup in time"))), CLEAR_TIMEOUT_MS);
			channel.port1.onmessage = (event) => {
				if (isOfflineWriteClearResult(event.data, requestId)) finish(resolve);
				else finish(() => reject(/* @__PURE__ */ new Error("The worker sent an invalid offline-write cleanup acknowledgement")));
			};
			channel.port1.onmessageerror = () => finish(() => reject(/* @__PURE__ */ new Error("The worker sent an unreadable offline-write cleanup acknowledgement")));
			channel.port1.start();
			try {
				worker.postMessage({
					type: "pwa:offline-write:clear",
					version: 1,
					requestId
				}, [channel.port2]);
			} catch (error) {
				finish(() => reject(error));
			}
		});
	}
	/**
	* Listens for the worker's runtime-cache-served signal (spec "页面信号"). Accepts only a message from the current
	* controller whose shape sw-runtime's own validator recognizes; everything else — another app's worker, a
	* malformed payload, a message some other part of the application posted — is ignored silently, never thrown or
	* logged. Does not call `container.startMessages()`: that would release every queued worker message the moment
	* this listener attaches, ahead of any listener the application itself adds, changing delivery order for every
	* app regardless of whether it uses this feature. The browser starts delivering messages on its own once any
	* listener is attached and the page performs another turn of the event loop, so a listener added here still
	* observes messages, just not ones queued before the *first* listener anywhere on the page attached.
	*
	* The listener is tied to the registration's lifetime, not the facade's: `forgetRegistration()` removes it, so a
	* register → logout → register cycle ends up with exactly one listener, not one per registration.
	*/
	function startRuntimeCacheMessages() {
		const onMessage = (event) => {
			if (event.source !== container.controller) return;
			if (!isRuntimeCacheServedMessage(event.data)) return;
			const { url, cachedAt, reason } = event.data;
			emit("served-from-cache", {
				url,
				cachedAt,
				reason
			});
		};
		container.addEventListener("message", onMessage);
		stopRuntimeCacheMessages = track(() => container.removeEventListener("message", onMessage));
	}
	/**
	* Asks the controller once, right after registration, whether a navigation it just served from the runtime cache
	* has a signal stashed for this page (spec "页面信号": the worker cannot deliver that one by direct `postMessage`
	* because this page starts listening after the navigation, so it is fetched instead). A timeout, a malformed
	* reply, a failed post or no controller at all all mean silence — never an error, never a retry.
	*/
	function queryPendingServed(worker) {
		const channel = createMessageChannel();
		let finished = false;
		const finish = () => {
			if (finished) return;
			finished = true;
			clearTimeout(timeout);
			channel.port1.onmessage = null;
			channel.port1.close();
			untrack();
		};
		const untrack = track(finish);
		const timeout = setTimeout(finish, RUNTIME_CACHE_PENDING_TIMEOUT_MS);
		channel.port1.onmessage = (event) => {
			if (isRuntimeCachePendingResult(event.data) && event.data.served !== null) {
				const { url, cachedAt, reason } = event.data.served;
				emit("served-from-cache", {
					url,
					cachedAt,
					reason
				});
			}
			finish();
		};
		channel.port1.onmessageerror = () => finish();
		channel.port1.start();
		try {
			worker.postMessage({
				type: "pwa:runtime-cache:pending",
				version: 1
			}, [channel.port2]);
		} catch {
			finish();
		}
	}
	/**
	* The browser's registration for exactly this scope, if its active worker already runs this app's worker script
	* (ADR-0043). A registration of a wider scope, one with only an installing or waiting worker, one running another
	* script, or a failed lookup all return undefined, so the caller waits for register() as before.
	*/
	async function activeRegistration() {
		try {
			const current = await container.getRegistration(config.scope);
			const active = current?.active;
			if (current === void 0 || active === null || active === void 0) return void 0;
			if (current.scope !== new URL(config.scope, current.scope).href) return void 0;
			return active.scriptURL === new URL(config.serviceWorkerUrl, current.scope).href ? current : void 0;
		} catch {
			return;
		}
	}
	function forgetRegistration() {
		stopWatching?.();
		stopWatching = void 0;
		stopRuntimeCacheMessages?.();
		stopRuntimeCacheMessages = void 0;
		registration = void 0;
		announcedWaiting = void 0;
		scheduler?.stop();
	}
	const scheduler = updateCheckIntervalMs !== void 0 && updateCheckDocument !== void 0 ? createUpdateScheduler({
		intervalMs: updateCheckIntervalMs,
		document: updateCheckDocument,
		runCheck: sharedUpdateCheck,
		track
	}) : void 0;
	if (config.installEnabled) {
		const target = options.target ?? defaultTarget();
		const onBeforeInstallPrompt = (event) => {
			event.preventDefault();
			installPrompt = event;
			emit("install-eligible", {});
		};
		const onAppInstalled = () => {
			installPrompt = void 0;
			emit("installed", {});
		};
		target.addEventListener("beforeinstallprompt", onBeforeInstallPrompt);
		target.addEventListener("appinstalled", onAppInstalled);
		track(() => {
			target.removeEventListener("beforeinstallprompt", onBeforeInstallPrompt);
			target.removeEventListener("appinstalled", onAppInstalled);
		});
	}
	return {
		async register() {
			alive();
			if (registration === void 0) {
				const pending = container.register(config.serviceWorkerUrl, { scope: config.scope });
				registration = activeRegistration().then((existing) => {
					if (existing === void 0) return pending;
					pending.catch(() => void 0);
					return existing;
				}).catch((error) => {
					registration = void 0;
					throw error;
				});
				const result = await registration;
				if (disposed) return;
				emit("registered", { scope: result.scope });
				stopWatching = watchForUpdates(result);
				scheduler?.start();
				startRuntimeCacheMessages();
				if (container.controller !== null) queryPendingServed(container.controller);
				return;
			}
			await registration;
		},
		async promptInstall() {
			alive();
			const pending = installPrompt;
			if (pending === void 0) return "unavailable";
			installPrompt = void 0;
			await pending.prompt();
			const { outcome } = await pending.userChoice;
			return outcome;
		},
		async applyUpdate() {
			alive();
			const waiting = (await container.getRegistration(config.scope))?.waiting;
			if (waiting === void 0 || waiting === null) return false;
			const controlled = takeover();
			try {
				waiting.postMessage(SKIP_WAITING_MESSAGE);
			} catch (error) {
				controlled.cancel();
				await controlled.settled.catch(() => void 0);
				throw error;
			}
			await controlled.settled;
			return true;
		},
		async logout() {
			alive();
			const current = await container.getRegistration(config.scope);
			const controller = container.controller;
			if (current === void 0) {
				forgetRegistration();
				return false;
			}
			if (controller === null) return false;
			try {
				await clearOfflineWrites(controller);
			} catch {
				return false;
			}
			const unregistered = await current.unregister();
			forgetRegistration();
			return unregistered;
		},
		async checkForUpdate() {
			alive();
			return sharedUpdateCheck();
		},
		subscribe(listener) {
			alive();
			listeners.add(listener);
			return () => {
				listeners.delete(listener);
			};
		},
		dispose() {
			if (disposed) return;
			disposed = true;
			scheduler?.stop();
			for (const undo of [...teardown]) undo();
			teardown.clear();
			stopWatching = void 0;
			listeners.clear();
			installPrompt = void 0;
		}
	};
}
function defaultContainer() {
	if (typeof navigator === "undefined" || navigator.serviceWorker === void 0) throw new Error("This environment has no navigator.serviceWorker; pass options.container explicitly");
	return navigator.serviceWorker;
}
function defaultTarget() {
	if (typeof window === "undefined") throw new Error("This environment has no window for the install events; pass options.target explicitly");
	return window;
}
function defaultDocument() {
	if (typeof document === "undefined") throw new Error("This environment has no document for the automatic update check; pass options.document explicitly");
	return document;
}
//#endregion
//#region browser-tests/app/src/main.ts
var events = [];
var client = createPwaClient({ config: _virtual_pwa_config_default });
client.subscribe((event) => events.push(event));
Reflect.set(window, "__pwaClient", client);
Reflect.set(window, "__pwaEvents", events);
Reflect.set(window, "__pwaConfig", _virtual_pwa_config_default);
//#endregion
