(function() {
	//#region ../sw-runtime/dist/shared/config.js
	var APP_CACHE_PREFIX = /^pwa:[^:]+:[^:]+:$/;
	var OFFLINE_WRITE_DATABASE_NAME = /^pwa-offline-write:[^:]+:[^:]+:[^:]+$/;
	var RECOVERY_KEYS = [
		"kind",
		"version",
		"appCachePrefix",
		"offlineWriteDatabaseName"
	];
	/** Validates a recovery worker config and returns a fresh copy with keys in canonical order. Messages name fields only. */
	function validateRecoveryWorkerConfig(value) {
		const config = plainObject(value, "config");
		exactKeys(config, RECOVERY_KEYS, "config");
		if (config["kind"] !== "recovery") fail("config.kind must be \"recovery\"");
		if (config["version"] !== 1) fail("config.version must be 1");
		const appCachePrefix = config["appCachePrefix"];
		if (typeof appCachePrefix !== "string" || !APP_CACHE_PREFIX.test(appCachePrefix)) fail("config.appCachePrefix must have the form \"pwa:<app>:<environment>:\"");
		const offlineWriteDatabaseName = config["offlineWriteDatabaseName"];
		if (typeof offlineWriteDatabaseName !== "string" || !OFFLINE_WRITE_DATABASE_NAME.test(offlineWriteDatabaseName)) fail("config.offlineWriteDatabaseName must have the form \"pwa-offline-write:<app>:<environment>:<seed>\"");
		return {
			kind: "recovery",
			version: 1,
			appCachePrefix,
			offlineWriteDatabaseName
		};
	}
	function fail(detail) {
		throw new Error(`Invalid sw-runtime worker config: ${detail}`);
	}
	function plainObject(value, label) {
		const prototype = typeof value === "object" && value !== null ? Object.getPrototypeOf(value) : void 0;
		if (Array.isArray(value) || prototype !== Object.prototype && prototype !== null) fail(`${label} must be a plain object`);
		return value;
	}
	function exactKeys(record, keys, label) {
		if (Reflect.ownKeys(record).length !== keys.length || !keys.every((key) => Object.hasOwn(record, key))) fail(`${label} must have exactly the fields ${keys.join(", ")}`);
	}
	//#endregion
	//#region ../sw-runtime/dist/shared/expiration-records.js
	var DATABASE_NAME = "workbox-expiration";
	var DATABASE_VERSION = 1;
	var OBJECT_STORE_NAME = "cache-entries";
	/**
	* Deletes every `workbox-expiration` record whose `cacheName` field satisfies `matches`. Never creates the database:
	* when `indexedDB.databases` reports it does not exist, this returns without opening anything; when `databases` is
	* unavailable, it opens without forcing a version bump and, if that open turns out to create the database (an
	* `upgradeneeded` fires), aborts the upgrade transaction so nothing is left behind and returns. A missing
	* `cache-entries` store (a `workbox-expiration` from some future/incompatible schema) is treated the same way.
	*/
	async function deleteExpirationRecords(matches) {
		if (!await mayExist()) return;
		const db = await openExistingDatabase();
		if (db === void 0) return;
		try {
			if (!db.objectStoreNames.contains(OBJECT_STORE_NAME)) return;
			await deleteMatchingRecords(db, matches);
		} finally {
			db.close();
		}
	}
	/** `false` only when `indexedDB.databases` is available and its listing does not include `workbox-expiration`. */
	async function mayExist() {
		if (typeof indexedDB.databases !== "function") return true;
		return (await indexedDB.databases()).some((entry) => entry.name === DATABASE_NAME);
	}
	/**
	* Opens `workbox-expiration` at its known version without creating it: an `upgradeneeded` firing means no such
	* database existed yet, so the transaction is aborted (which discards the database `open` would otherwise have just
	* created) and this resolves to `undefined` instead of a connection.
	*/
	function openExistingDatabase() {
		return new Promise((resolve, reject) => {
			let didNotExist = false;
			const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
			request.onupgradeneeded = () => {
				didNotExist = true;
				request.transaction?.abort();
			};
			request.onsuccess = () => resolve(request.result);
			request.onerror = () => {
				if (didNotExist) {
					resolve(void 0);
					return;
				}
				reject(request.error ?? /* @__PURE__ */ new Error("workbox-expiration open failed"));
			};
		});
	}
	/** One readwrite transaction: every entry whose `cacheName` matches is deleted while the cursor walks the store. */
	function deleteMatchingRecords(db, matches) {
		return new Promise((resolve, reject) => {
			const transaction = db.transaction(OBJECT_STORE_NAME, "readwrite");
			transaction.oncomplete = () => resolve();
			transaction.onerror = () => reject(transaction.error ?? /* @__PURE__ */ new Error("workbox-expiration record deletion failed"));
			transaction.onabort = () => reject(transaction.error ?? /* @__PURE__ */ new Error("workbox-expiration record deletion aborted"));
			const request = transaction.objectStore(OBJECT_STORE_NAME).openCursor();
			request.onerror = () => reject(request.error ?? /* @__PURE__ */ new Error("workbox-expiration cursor failed"));
			request.onsuccess = () => {
				const cursor = request.result;
				if (cursor === null) return;
				const cacheName = cursor.value.cacheName;
				if (typeof cacheName === "string" && matches(cacheName)) cursor.delete();
				cursor.continue();
			};
		});
	}
	//#endregion
	//#region ../sw-runtime/dist/recovery-worker/index.js
	/**
	* How long the offline-write database deletion keeps waiting after `onblocked` before it is treated as a failure.
	* The platform's own store closes each connection as soon as its transaction ends, so a legitimate block clears in
	* milliseconds; a connection that never closes (application code holding the platform's database open) does not
	* clear at all in Chrome, and until this expires `activate` — and so recovery — is held up.
	*/
	var BLOCKED_WAIT_MS = 3e3;
	/**
	* Registers the recovery worker (ADR-0005): it takes over immediately only after it removes every cache and the
	* identity-derived offline-write database of this app in this environment, then serves nothing, so page requests go
	* straight to the network. On activation it also cancels this registration's push subscription, after deletion and
	* before claiming clients, so the business backend starts seeing failed sends and can clean up (ADR-0021, "对
	* ADR-0012 的修订").
	*
	* It registers only `install` and `activate`; it never registers `fetch`, `push` or `notificationclick`, never opens
	* a cache and never deletes a cache outside `config.appCachePrefix`.
	*/
	function registerRecoveryWorker({ scope, config }) {
		const { appCachePrefix, offlineWriteDatabaseName } = validateRecoveryWorkerConfig(config);
		scope.addEventListener("install", (event) => {
			event.waitUntil(scope.skipWaiting());
		});
		scope.addEventListener("activate", (event) => {
			event.waitUntil(recover(scope, appCachePrefix, offlineWriteDatabaseName));
		});
	}
	/**
	* Deletes this app's caches, this app's workbox-expiration records (best effort — see below), and the
	* identity-derived queue database, cancels this registration's push subscription (if any), then claims the open
	* clients so they stop being controlled by the broken worker. Cancelling the subscription never blocks deletion or
	* takeover: it runs after deletion and before claim, and its own failure is swallowed.
	*
	* One failed deletion never stops the others (review #15): the activate event runs once, so whatever is skipped here
	* would stay behind until the next deployment. After every deletion was attempted, any failure rejects before the
	* push step and the claim, so recovery still fails closed.
	*/
	async function recover(scope, appCachePrefix, offlineWriteDatabaseName) {
		const failures = [];
		const record = (error) => {
			failures.push(error);
		};
		for (const name of await scope.caches.keys()) if (name.startsWith(appCachePrefix)) await scope.caches.delete(name).catch(record);
		await deleteExpirationRecordsBestEffort(appCachePrefix);
		await deleteOfflineWriteDatabase(offlineWriteDatabaseName).catch(record);
		if (failures.length > 0) throw failures[0];
		await cancelPushSubscription(scope);
		await scope.clients.claim();
	}
	/**
	* Best-effort, like the push-subscription cancellation below: a failure here must never block deleting the
	* identity-derived offline-write database or claiming clients, so it is swallowed rather than propagated.
	*/
	async function deleteExpirationRecordsBestEffort(appCachePrefix) {
		try {
			await deleteExpirationRecords((name) => name.startsWith(appCachePrefix));
		} catch {}
	}
	/**
	* Rejects on failure so recovery does not take control while sensitive queue data remains. `onblocked` alone is not
	* a failure (ADR-0012 addendum, R14 residue): it only means another connection to this database has not closed yet
	* — the delete request stays pending in the browser and usually still succeeds once that connection closes. So a
	* `blocked` event keeps this waiting for the eventual `onsuccess`/`onerror`, bounded by `BLOCKED_WAIT_MS`; only a
	* timeout after `blocked`, or an outright `onerror`, is treated as a failure.
	*/
	function deleteOfflineWriteDatabase(name) {
		return new Promise((resolve, reject) => {
			const request = indexedDB.deleteDatabase(name);
			let timer;
			request.onsuccess = () => {
				if (timer !== void 0) clearTimeout(timer);
				resolve();
			};
			request.onerror = () => {
				if (timer !== void 0) clearTimeout(timer);
				reject(request.error ?? /* @__PURE__ */ new Error("offline-write database deletion failed"));
			};
			request.onblocked = () => {
				timer = setTimeout(() => reject(/* @__PURE__ */ new Error("offline-write database deletion blocked")), BLOCKED_WAIT_MS);
			};
		});
	}
	/** Best-effort: environments without a `pushManager` are skipped, and any rejection here is swallowed (ADR-0021). */
	async function cancelPushSubscription(scope) {
		if (!("pushManager" in scope.registration)) return;
		try {
			const subscription = await scope.registration.pushManager.getSubscription();
			if (subscription !== null) await subscription.unsubscribe();
		} catch {}
	}
	//#endregion
	//#region ../sw-runtime/dist/entries/recovery-worker-entry.js
	registerRecoveryWorker({
		scope: self,
		config: {"kind":"recovery","version":1,"appCachePrefix":"pwa:vitefixture:production:","offlineWriteDatabaseName":"pwa-offline-write:vitefixture:production:r1"}
	});
	//#endregion
})();
